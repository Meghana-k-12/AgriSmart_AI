# 🌾 AgriSmart AI — Sustainable Agriculture Advisory System

## 1. Problem statement
**PS 14 – AI-Based Sustainable Agriculture Advisory System.** Farmers need reliable,
contextual advice on **crop selection, irrigation practices, soil management, pest
prevention and sustainable farming methods**. They often can't read English easily and
can't verify what a generic AI chatbot tells them. A chatbot that invents a pesticide dose
can cause real harm.

## 2. Proposed solution
AgriSmart AI is a **multilingual, voice-enabled agricultural RAG chatbot**. It answers
**only from trusted agricultural documents**, cites the document file name and PDF page
behind every answer, and says clearly when the documents don't contain the answer.
Farmers can type or speak in **English, Telugu, Kannada or Hindi** and listen to the answer.

## 3. System architecture

```
 ┌───────────────────────── INGESTION  (python ingest.py) ─────────────────────────┐
 │ data/*.pdf ─► PyMuPDF (text per span + font) ─► Nudi-font Kannada → Unicode       │
 │   ─► cleaning (TOC/title pages removed) ─► chunks ≈800 chars, 150 overlap,        │
 │      one page at a time (keeps file name + PDF page)                              │
 │   ─► multilingual MiniLM embeddings (384-d, normalised)                           │
 │   ─► ChromaDB (vector_db/, cosine) + manifest.json (SHA-1 per PDF → skip reindex) │
 └──────────────────────────────────────────────────────────────────────────────────┘
 ┌───────────────────────── QUESTION ANSWERING  (streamlit run app.py) ────────────┐
 │ 🎤 voice ─► Whisper (local) / Gemini (cloud) speech-to-text ─► editable text     │
 │ ⌨️ text  ───────────────────────────────────────────────────┘                     │
 │   ─► language detected; Telugu/Kannada/Hindi question also translated to English │
 │   ─► ChromaDB top-k search with BOTH queries ─► merge ─► cosine threshold         │
 │        (no evidence at all → "not enough information", Gemini is not called)     │
 │   ─► Gemini + strict grounding prompt (retrieved passages numbered [S1]…)         │
 │   ─► answer in the selected language, with [S#] citations                         │
 │   ─► 📚 sources: title, publisher, file name, PDF pages, retrieved passages        │
 │   ─► 🔊 gTTS / Google Cloud TTS ─► farmer listens (replay button on every answer) │
 └──────────────────────────────────────────────────────────────────────────────────┘
```

## 4. Technologies used
| Layer | Technology |
|---|---|
| Language | Python 3.11 (3.10–3.12 supported) |
| PDF extraction | PyMuPDF (pdfplumber fallback) + custom Nudi→Unicode Kannada converter |
| Embeddings | `sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2` |
| Vector DB | ChromaDB (persistent, cosine space) |
| LLM | Google Gemini via the official `google-genai` SDK (default `gemini-3.8-flash`, automatic fallback) |
| UI | Streamlit (≥1.40 for `st.audio_input` microphone) |
| Speech-to-text | OpenAI Whisper (local) or Gemini audio transcription |
| Text-to-speech | gTTS (free) or Google Cloud Text-to-Speech (optional) |
| Config | python-dotenv (`.env`) |

LangChain is **not** used. The pipeline is small enough that plain Python is clearer and
avoids an extra dependency; its chunking strategy (recursive splitting with overlap) is
implemented in `modules/text_processor.py`.

## 5. Knowledge sources

| File in `data/` | Document | Publisher | Language | PDF pages (with text) | Chunks |
|---|---|---|---|---|---|
| `AGRICULTURE_2.pdf` | Crop Production Guide – Agriculture 2020 | TNAU & Directorate of Agriculture, Tamil Nadu | English | 460 (454) | 1509 |
| `POP-Final-Book-2025_1.pdf` | Package of Practices 2025 | UAS Bangalore | **Kannada** | 225 (224) | 614 |
| `Compilation_techniques_organic_agriculture_rev_3.pdf` | Training Manual for Organic Agriculture (2015) | FAO | English | 105 (105) | 333 |
| `Agriculture-Science_04.pdf` | Handbook on Agroecology: Farmer's Manual on Sustainable Practices (Dec 2014) | Focus on the Global South, India (P. T. George & Afsar Jafri) | English | 90 (88) | 341 |

**About the fourth PDF.** It is **not** an FAO manual. Its embedded PDF metadata says
`Title: Agriculture Science.cdr`, `Author: Romy`, created with CorelDRAW X7 in April 2015.
That's the designer's file name, not a real title. The title page identifies it as the
*Handbook on Agroecology*, published by Focus on the Global South with support from
Rosa Luxemburg Stiftung, and says its contents "can be freely reproduced and quoted on
the condition that the source be mentioned". The loader now rejects design-file metadata
titles like `*.cdr` automatically, and `data/sources.json` gives the correct title and
publisher.

**Data collection method.** No dataset was scraped or generated. The four PDFs were
downloaded manually from the publishers' public websites and are used unchanged. No
Kaggle or other dataset is used. The only transformation is text extraction, plus
Unicode conversion of the Kannada book.

**Adding documents.** Put any PDF into `data/` and run `python ingest.py`. New, changed or
removed PDFs are detected (by SHA-1 fingerprint) and the index is rebuilt. Add an entry to
`data/sources.json` to set a nice title; without one, the title comes from the PDF metadata
(if it is meaningful) or the file name. For a web resource such as the
[TNAU crop protection portal](https://www.agritech.tnau.ac.in/crop_protection/crop_prot.html),
open the pages in a browser, *Print → Save as PDF* into `data/`, and re-run ingestion.

### Topic coverage (measured, not assumed)
Number of chunks (and distinct PDF pages) whose text matches topic keywords in English
and Kannada, measured on the extracted text:

| Topic | FAO | Agroecology handbook | TNAU | UAS Bangalore (Kannada) | Verdict |
|---|---|---|---|---|---|
| 1 Crop selection | 60 (33 p) | 34 (21 p) | 389 (242 p) | 150 (97 p) | **Supported, region-specific.** Crop-wise varieties, seasons and soils; district/soil-wise sowing plans (TNAU ≈ pp. 420–440); agro-climatic zones & red soils (UAS pp. 15–16). No general "which crop for which soil" table, so answers are specific to Tamil Nadu / southern Karnataka |
| 2 Irrigation | 18 (10 p) | 20 (13 p) | 396 (222 p) | 102 (59 p) | **Strong.** Drip/sprinkler sections and crop-wise irrigation schedules (TNAU), water saving (FAO ch. 5), rice water management (UAS pp. 30–31) |
| 3 Soil management | 84 (44 p) | 84 (38 p) | 277 (141 p) | 234 (103 p) | **Strong.** Soil fertility, compost, green manure (FAO ch. 6–7), INM (TNAU) |
| 4 Pest prevention | 94 (45 p) | 72 (38 p) | 252 (126 p) | 116 (69 p) | **Strong.** FAO ch. 8 "Prevention practices and monitoring", crop-wise IPM modules (TNAU), neem/botanical preparations (handbook), Kannada crop-protection sections (UAS). An extra pest source was **not needed** |
| 5 Sustainable farming | 109 (61 p) | 143 (59 p) | 101 (64 p) | 34 (24 p) | **Strong.** Crop rotation, intercropping, mulching, agroecology |

Keyword matches show that a topic is present, not how good the answers are. Answer quality
is checked with `tests/test_live.py` (section 9).

## 6. RAG workflow (what happens to one question)
1. **Question** typed, or spoken and transcribed (you can edit the text before sending).
2. **Language**: the answer is written in the language chosen in the header. If the header
   is still on English but the question is clearly Telugu/Kannada/Hindi, that language is used.
3. **Query translation**: for non-English questions, Gemini makes a short English version.
   Both versions are searched.
4. **Retrieval**: each query is embedded and the top-k (`TOP_K=6`) chunks are taken from
   ChromaDB, then merged.
5. **Threshold**: similarity is **cosine similarity** (ChromaDB returns cosine *distance*;
   `similarity = 1 − distance`; embeddings are normalised, range −1…1). Chunks with
   similarity ≥ `MIN_SIMILARITY` (0.25) are used. If none qualify, up to 3 chunks with
   similarity ≥ `SIMILARITY_FLOOR` (0.15) are still given to Gemini as "weak matches".
   This prevents false "not found" answers, and Gemini must reply `NOT_FOUND` if they are
   irrelevant. Below the floor, the app answers "not enough information" **without calling
   Gemini**.
6. **Generation**: Gemini receives the numbered passages (title, publisher, file name,
   PDF page, text). Its rules: cite `[S#]` after every fact, never invent quantities or
   doses, separate document facts from general guidance, say whether the source is
   region-specific, recommend the KVK, no disease diagnosis, no guarantees.
7. **Sources**: only the passages Gemini cited are listed (file name + PDF pages); every
   retrieved passage and both search queries can be inspected under 📚 Sources.

## 7. Multilingual and voice functionality
* **UI**: every label, topic card, suggested question, error and disclaimer exists in
  English, Telugu, Kannada and Hindi.
* **Retrieval across languages**: the required embedding model covers English and Hindi
  but **not Telugu or Kannada**, so Telugu/Kannada questions rely on the English query
  translation to match the English PDFs. Kannada questions also match the (converted)
  Kannada UAS book directly.
* **Speech-to-text**: the microphone is Streamlit's `st.audio_input`, a real browser
  recording sent as WAV. Choose **Whisper** (local, free, weaker for Telugu/Kannada) or
  **Gemini** (cloud, recommended for Telugu/Kannada) in the sidebar. The recognised text
  appears in the question box before sending (or turn on "send immediately").
* **Text-to-speech**: 🔊 button on every answer, plus an optional "read answers aloud"
  toggle. It uses gTTS (en/te/kn/hi) or Google Cloud TTS when credentials are set.
  Citations and markdown are stripped before speaking.
* **Errors handled**: no or short or silent recording, browser mic blocked (help text),
  Whisper not installed, Gemini key missing/invalid, model unavailable, quota, no internet,
  TTS failure. Each shows a message and the chat keeps working.

## 8. Installation and execution

### 8.1 Install (Windows, Python 3.11)
```bash
cd AgriSmart_AI
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```
On Mac/Linux use `python3.11 -m venv .venv` and `source .venv/bin/activate`.
PyTorch (installed with sentence-transformers) is large (~1–2 GB). If `openai-whisper`
fails to install, delete that line from `requirements.txt` and use **Gemini** speech
recognition in the sidebar.

### 8.2 API key (`.env`)
```bash
copy .env.example .env        # Mac/Linux: cp .env.example .env
```
1. Open https://aistudio.google.com/apikey → **Create API key**.
2. Open `.env` in Notepad and replace the placeholder: `GOOGLE_API_KEY=AIza...your key...`
   (no quotes, no spaces).
3. Leave `GEMINI_MODEL=gemini-3.8-flash`. If that model isn't available for your key, the
   app automatically tries `gemini-3.5-flash-lite`, then `gemini-2.5-flash`. You can also
   set a list: `GEMINI_MODEL=gemini-3.8-flash,gemini-3.5-flash-lite`.
4. Never commit `.env` (it is in `.gitignore`).

### 8.3 Run, in this order
```bash
python -m unittest tests.test_offline -v      # 25 tests, no internet needed
python ingest.py                              # builds vector_db/ (first run downloads ~470 MB model)
python ingest.py                              # should say "Knowledge base is up to date"
python tests/test_live.py --retrieval-only    # real embeddings + ChromaDB, no API key
python tests/test_live.py                     # full RAG with Gemini; writes tests/live_report.md
python tests/test_live.py --voice             # also writes tests/tts_*.mp3 for 4 languages
streamlit run app.py                          # opens http://localhost:8501
```
The microphone works on `http://localhost`. From another device, the browser requires HTTPS.

## 9. Test results

### Executed in the build environment (results are real)
| Test | Result |
|---|---|
| `python -m unittest tests.test_offline -v` on Python 3.13 | **25/25 OK** |
| Same on **Python 3.11.18** | **21 OK, 4 skipped** (voice helpers need numpy, which isn't installed for 3.11 there) |
| `py_compile` of every `.py` file on Python 3.11 | **All OK** |
| Text extraction of the 4 PDFs | 871 of 880 pages have text; 0 failures; **2797 chunks** |
| Kannada Nudi conversion | 76% Kannada script, < 0.1% leftover glyph junk; spot-checked by reading pages |
| `ingest()` with stand-in embedder/store | rebuilt → second run "up to date" → **adding a new PDF triggered a rebuild** ("new file: …") |
| App control flow (fake Streamlit, 10 steps) | render, suggestion click → answer with sources, Kannada voice → answer, Whisper missing → error, empty question, TTS missing → error, clear chat, sidebar rebuild — **no crash** |
| `tests/test_live.py` with a TF-IDF stand-in | ran end to end with no errors; the Kannada rice-irrigation question retrieved UAS Bangalore pp. 30–31 |

### Not yet executed (packages couldn't be installed in the build environment)
Real MiniLM embeddings, ChromaDB persistence, Gemini answers, Whisper, gTTS and the live
Streamlit page. `tests/test_live.py` checks them on your laptop: it prints **PASS/CHECK**
for each of the 18 questions (5 topics × 2, Telugu, Kannada, Hindi, 2 missing-info). It
checks the answer language, multiple-document citation and UAS Bangalore retrieval, and
prints a **threshold calibration** from your real similarity scores. Paste its summary
into this section after running it.

## 10. Limitations and future enhancements
**Limitations**
* Page references are **PDF page numbers**, not the numbers printed in the books.
* TNAU advice applies to Tamil Nadu and UAS advice to southern Karnataka; the app says so,
  but it has no farmer-location input yet.
* The embedding model doesn't cover Telugu/Kannada; cross-language retrieval depends on
  Gemini query translation (an internet connection is needed).
* Whisper's Telugu/Kannada accuracy is limited; Gemini STT is recommended for those languages.
* gTTS uses an unofficial Google endpoint and needs internet.
* The model reads at most 256 tokens per chunk (`EMBEDDING_MAX_SEQ_LENGTH`), so the end of
  long Kannada chunks may not be embedded (Gemini still receives the full text).
* Advisory only: no disease diagnosis, no yield guarantees.

**Future enhancements**
* Bhashini (Govt. of India) ASR/TTS for Indian languages (needs ULCA registration and API keys).
* An embedding model with Telugu/Kannada coverage (e.g. a multilingual E5 model), compared with the current one.
* Farmer profile (district, soil, season) to filter region-specific sources.
* More state Package-of-Practices books (Telangana, Andhra Pradesh), ICAR and TNAU crop-protection pages.
* Offline mode with a local LLM; WhatsApp/IVR access for basic phones.

See **`HACKATHON_GUIDE.md`** for the 5-minute demo script, 15 likely judge questions with
answers, and why RAG is used instead of training a model.
