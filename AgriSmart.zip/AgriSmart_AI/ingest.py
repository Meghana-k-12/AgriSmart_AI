"""
Build (or rebuild) the ChromaDB knowledge base from the PDFs in data/.

    python ingest.py            # index only if PDFs/settings changed
    python ingest.py --rebuild  # force a full rebuild
    python ingest.py --check    # only report whether a rebuild is needed
"""

from __future__ import annotations

import argparse
import logging
import sys
import time

import config
from modules.document_loader import find_pdfs, load_documents
from modules.text_processor import chunk_pages
from modules.vector_store import (VectorStore, build_manifest, manifest_changes,
                                  read_manifest, write_manifest)

log = logging.getLogger("ingest")


def current_settings() -> dict:
    return {"embedding_model": config.EMBEDDING_MODEL,
            "max_seq_length": config.EMBEDDING_MAX_SEQ_LENGTH,
            "chunk_size": config.CHUNK_SIZE, "chunk_overlap": config.CHUNK_OVERLAP,
            "loader_version": 3}


def ingest(force: bool = False, embedder=None, store=None, progress=print) -> dict:
    """Run the full pipeline. Returns a summary dict. Safe to call from the UI."""
    pdfs = find_pdfs(config.DATA_DIR)
    if not pdfs:
        raise FileNotFoundError(
            f"No PDF files found in {config.DATA_DIR}. Copy your agricultural PDFs there.")

    new_manifest = build_manifest(pdfs, current_settings())
    store = store or VectorStore(config.VECTOR_DB_DIR, config.COLLECTION_NAME)
    reasons = manifest_changes(read_manifest(config.MANIFEST_FILE), new_manifest)
    if store.count() == 0 and not reasons:
        reasons = ["vector database is empty"]
    if not reasons and not force:
        progress(f"Knowledge base is up to date ({store.count()} chunks). "
                 "Use --rebuild to force re-indexing.")
        return {"status": "up_to_date", "chunks": store.count()}

    progress("Rebuilding because: " + ("forced" if force and not reasons else "; ".join(reasons)))
    t0 = time.time()

    # 1. Extract
    pages, report = load_documents(config.DATA_DIR, config.SOURCES_FILE,
                                   config.MIN_PAGE_CHARS, progress=progress)
    for name, info in report.loaded.items():
        progress(f"  ✓ {info['title']}: {info['text_pages']}/{info['pages']} pages with text")
    for name, err in report.failed.items():
        progress(f"  ✗ {name}: {err}")
    for w in report.warnings:
        progress(f"  ! {w}")
    if not pages:
        raise RuntimeError("No text could be extracted from any PDF.")

    # 2. Clean + chunk
    chunks = chunk_pages(pages, config.CHUNK_SIZE, config.CHUNK_OVERLAP)
    progress(f"Created {len(chunks)} chunks (size≈{config.CHUNK_SIZE}, "
             f"overlap≈{config.CHUNK_OVERLAP}) in {time.time() - t0:.1f}s")

    # 3. Embed
    if embedder is None:
        from modules.embeddings import Embedder
        embedder = Embedder(config.EMBEDDING_MODEL, config.EMBEDDING_MAX_SEQ_LENGTH)
    progress(f"Embedding with {config.EMBEDDING_MODEL} (first run downloads the model)…")
    t1 = time.time()
    vectors = embedder.embed_documents([c.text for c in chunks])
    progress(f"Embedded {len(vectors)} chunks in {time.time() - t1:.1f}s "
             f"(dimension {len(vectors[0])})")

    # 4. Store
    store.reset()
    store.add([c.id for c in chunks], [c.text for c in chunks], vectors,
              [c.metadata for c in chunks])
    write_manifest(config.MANIFEST_FILE, new_manifest)
    progress(f"Stored {store.count()} chunks in ChromaDB at {config.VECTOR_DB_DIR}")

    per_doc = {}
    for c in chunks:
        per_doc[c.metadata["title"]] = per_doc.get(c.metadata["title"], 0) + 1
    return {"status": "rebuilt", "chunks": store.count(), "per_document": per_doc,
            "failed": report.failed, "warnings": report.warnings,
            "seconds": round(time.time() - t0, 1)}


def main() -> int:
    ap = argparse.ArgumentParser(description="Index agricultural PDFs into ChromaDB")
    ap.add_argument("--rebuild", action="store_true", help="force full re-index")
    ap.add_argument("--check", action="store_true", help="only report index status")
    args = ap.parse_args()
    logging.basicConfig(level=logging.WARNING, format="%(levelname)s %(message)s")

    try:
        if args.check:
            pdfs = find_pdfs(config.DATA_DIR)
            reasons = manifest_changes(read_manifest(config.MANIFEST_FILE),
                                       build_manifest(pdfs, current_settings()))
            print("Up to date." if not reasons else "Rebuild needed: " + "; ".join(reasons))
            return 0
        summary = ingest(force=args.rebuild)
    except Exception as exc:
        print(f"ERROR: {exc}")
        return 1

    if summary["status"] == "rebuilt":
        print("\nSummary (chunks per document):")
        for title, n in summary["per_document"].items():
            print(f"  {n:5d}  {title}")
        print(f"Total: {summary['chunks']} chunks in {summary['seconds']}s")
    return 0


if __name__ == "__main__":
    sys.exit(main())
