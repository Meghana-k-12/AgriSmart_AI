"""
Nudi (legacy ASCII) Kannada  ->  Unicode Kannada converter.

Why this exists
---------------
The UAS Bangalore "Package of Practices 2025" book is typed in the Nudi01e
font. Nudi does not store real Kannada characters: it stores Latin-1 codes
that the font *draws* as Kannada glyphs. Text extraction therefore returns
strings like "ªÀiÁ»w" instead of "ಮಾಹಿತಿ". Embeddings of that junk are
meaningless, so we convert it to proper Unicode before chunking.

Only text that was rendered in a Nudi font should be passed here
(document_loader checks the font name per text span). English text,
numbers and punctuation in other fonts are left untouched.

The mapping covers the glyphs actually found in the POP book. Rare letters
(ಙ, ಞ, ಝ, ಱ) are not mapped and pass through unchanged.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Glyph tables
# ---------------------------------------------------------------------------

# Independent vowels and other standalone letters
INDEPENDENT = {
    "C": "ಅ", "D": "ಆ", "E": "ಇ", "F": "ಈ", "G": "ಉ", "H": "ಊ", "IÄ": "ಋ",
    "J": "ಎ", "K": "ಏ", "L": "ಐ", "M": "ಒ", "N": "ಓ", "O": "ಔ",
}
MODIFIERS = {"A": "ಂ", "B": "ಃ"}

# Base consonant glyphs: glyph -> (consonant, carries built-in "i" vowel)
BASE = {
    "P": ("ಕ", False), "Q": ("ಕ", True),
    "R": ("ಖ", False), "S": ("ಖ", False), "T": ("ಖ", True),
    "U": ("ಗ", False), "V": ("ಗ", True),
    "W": ("ಘ", False), "X": ("ಘ", True),
    "Z": ("ಚ", False), "a": ("ಚ", True),
    "b": ("ಛ", False), "c": ("ಛ", True),
    "d": ("ಜ", False), "e": ("ಜ", False), "f": ("ಜ", True),
    "g": ("ರ", False), "j": ("ರ", True),
    "l": ("ಟ", False), "m": ("ಟ", False), "n": ("ಟ", True),
    "o": ("ಠ", False), "p": ("ಠ", True),
    "q": ("ಡ", False), "r": ("ಡ", True),
    "t": ("ಣ", False), "u": ("ಣ", False),
    "v": ("ತ", False), "w": ("ತ", True),
    "x": ("ಥ", False), "y": ("ಥ", True),
    "z": ("ದ", False), "¢": ("ದ", True),
    "£": ("ನ", False), "¤": ("ನ", True),
    "¥": ("ಪ", False), "¦": ("ಪ", True),
    "§": ("ಬ", False), "¨": ("ಬ", False), "©": ("ಬ", True),
    "ª": ("ವ", False), "«": ("ವ", True),
    "®": ("ಲ", False), "¯": ("ಲ", False), "°": ("ಲ", True),
    "±": ("ಶ", False), "²": ("ಶ", True),
    "µ": ("ಷ", False), "¶": ("ಷ", True),
    "¸": ("ಸ", False), "¹": ("ಸ", True),
    "º": ("ಹ", False), "»": ("ಹ", True),
    "¼": ("ಳ", False), "½": ("ಳ", True),
}

# Multi-glyph letters: ಮ and ಯ are drawn from several pieces in Nudi.
# value = (consonant, list of vowel flags)
SPECIAL = {
    "ªÀÄ": ("ಮ", []), "ªÀi": ("ಮ", []), "«Ä": ("ಮ", ["i"]),
    "ªÉÄ": ("ಮ", ["e"]), "ªÉÆ": ("ಮ", ["e", "uu"]), "ªÉÇ": ("ವ", ["e", "uu"]),
    "AiÀÄ": ("ಯ", []), "AiÀi": ("ಯ", []), "¬Ä": ("ಯ", ["i"]),
    "AiÉÄ": ("ಯ", ["e"]), "AiÉÆ": ("ಯ", ["e", "uu"]),
}

# Dependent vowel signs and marks -> flags
SIGNS = {
    "À": "a", "Á": "aa", "Â": "i", "Ã": "long", "Ä": "u", "Å": "u",
    "Æ": "uu", "Ç": "uu", "È": "r", "É": "e", "Ê": "ai", "Ë": "au",
    "ï": "virama", "s": "asp", "ü": "asp", "ö": "noop", "ø": "r",
    # spacing / nukta marks and stray pieces that carry no sound of their own
    "÷": "noop", "ó": "noop", "û": "noop", "i": "noop",
}

# Subscript consonants (ottakshara) -> consonant
SUBSCRIPT = {
    "Ì": "ಕ", "Í": "ಖ", "Î": "ಗ", "Ï": "ಘ", "Ñ": "ಚ", "Ò": "ಛ", "Ó": "ಜ",
    "Ô": "ಝ", "Õ": "ಞ", "Ö": "ಟ", "×": "ಠ", "Ø": "ಡ", "Ù": "ಢ", "Ú": "ಣ",
    "Û": "ತ", "Ü": "ಥ", "Ý": "ದ", "Þ": "ಧ", "ß": "ನ", "à": "ಪ", "á": "ಫ",
    "â": "ಬ", "ã": "ಭ", "ä": "ಮ", "å": "ಯ", "æ": "ರ", "ç": "ರ", "è": "ಲ",
    "é": "ವ", "ê": "ಶ", "ë": "ಷ", "ì": "ಸ", "í": "ಹ", "î": "ಳ",
}
REPH = "ð"  # arkavattu: "ರ್" placed before the syllable it is drawn on

ASPIRATE = {"ದ": "ಧ", "ಡ": "ಢ", "ಪ": "ಫ", "ಬ": "ಭ", "ತ": "ಥ", "ಗ": "ಘ",
            "ಚ": "ಛ", "ಜ": "ಝ", "ಕ": "ಖ", "ಟ": "ಠ"}

VIRAMA = "್"
SIGN_CHARS = {"aa": "ಾ", "i": "ಿ", "ii": "ೀ", "u": "ು", "uu": "ೂ", "r": "ೃ",
              "e": "ೆ", "ee": "ೇ", "ai": "ೈ", "o": "ೊ", "oo": "ೋ", "au": "ೌ"}

# Tokens sorted longest first for greedy matching
_TOKENS: list[tuple[str, tuple]] = []
for k, v in SPECIAL.items():
    _TOKENS.append((k, ("C", v[0], list(v[1]))))
for k, v in INDEPENDENT.items():
    _TOKENS.append((k, ("I", v)))
for k, v in MODIFIERS.items():
    _TOKENS.append((k, ("M", v)))
for k, (cons, has_i) in BASE.items():
    _TOKENS.append((k, ("C", cons, ["i"] if has_i else [])))
for k, v in SIGNS.items():
    _TOKENS.append((k, ("V", v)))
for k, v in SUBSCRIPT.items():
    _TOKENS.append((k, ("S", v)))
_TOKENS.append((REPH, ("R",)))
_TOKENS.sort(key=lambda kv: -len(kv[0]))
_MAXLEN = max(len(k) for k, _ in _TOKENS)
_LOOKUP = dict(_TOKENS)


def _vowel_sign(flags: list[str]) -> str:
    f = set(flags)
    if "virama" in f and not (f - {"virama", "a", "noop", "asp"}):
        return VIRAMA
    long_ = "long" in f
    if "i" in f:
        return SIGN_CHARS["ii" if long_ else "i"]
    if "e" in f:
        if "uu" in f:
            return SIGN_CHARS["oo" if long_ else "o"]
        if "ai" in f:
            return SIGN_CHARS["ai"]
        return SIGN_CHARS["ee" if long_ else "e"]
    for key in ("aa", "uu", "u", "r", "au", "ai"):
        if key in f:
            return SIGN_CHARS[key]
    return ""


class _Syllable:
    __slots__ = ("cons", "flags", "subs", "reph")

    def __init__(self, cons: str, flags: list[str]):
        self.cons, self.flags, self.subs, self.reph = cons, list(flags), [], False

    def render(self) -> str:
        cons = self.cons
        if "asp" in self.flags:
            cons = ASPIRATE.get(cons, cons)
        out = ("ರ" + VIRAMA if self.reph else "") + cons
        # ಯ-subscript is written last in Unicode (ಟ್ರ್ಯಾ, not ಟ್ಯ್ರಾ)
        subs = [s for s in self.subs if s != "ಯ"] + [s for s in self.subs if s == "ಯ"]
        out += "".join(VIRAMA + s for s in subs)
        return out + _vowel_sign(self.flags)


def nudi_to_unicode(text: str) -> str:
    """Convert a Nudi-encoded string into Unicode Kannada."""
    out: list[str] = []
    syl: _Syllable | None = None
    i, n = 0, len(text)

    def flush():
        nonlocal syl
        if syl is not None:
            out.append(syl.render())
            syl = None

    while i < n:
        tok = None
        for L in range(min(_MAXLEN, n - i), 0, -1):
            tok = _LOOKUP.get(text[i:i + L])
            if tok:
                i += L
                break
        if tok is None:                      # space, digit, punctuation …
            flush()
            out.append(text[i])
            i += 1
            continue

        kind = tok[0]
        if kind == "C":
            flush()
            syl = _Syllable(tok[1], tok[2])
        elif kind == "V":
            if syl is not None:
                syl.flags.append(tok[1])
            # a stray sign with no consonant is dropped
        elif kind == "S":
            if syl is not None:
                syl.subs.append(tok[1])
            else:
                out.append(VIRAMA + tok[1])
        elif kind == "R":
            if syl is not None:
                syl.reph = True
                flush()
            else:
                out.append("ರ" + VIRAMA)
        else:  # independent vowel / anusvara / visarga
            flush()
            out.append(tok[1])
    flush()
    return "".join(out)


def is_nudi_font(font_name: str | None) -> bool:
    """True for Nudi-family legacy fonts (Nudi01e, Nudi 01 e, NudiB…)."""
    return bool(font_name) and "nudi" in font_name.lower()
