"""Languages, script detection, and all farmer-facing UI text in 4 languages."""

from __future__ import annotations

LANGUAGES = {
    "en": {"name": "English", "native": "English", "whisper": "en", "gtts": "en",
           "gcloud": "en-IN"},
    "te": {"name": "Telugu", "native": "తెలుగు", "whisper": "te", "gtts": "te",
           "gcloud": "te-IN"},
    "kn": {"name": "Kannada", "native": "ಕನ್ನಡ", "whisper": "kn", "gtts": "kn",
           "gcloud": "kn-IN"},
    "hi": {"name": "Hindi", "native": "हिन्दी", "whisper": "hi", "gtts": "hi",
           "gcloud": "hi-IN"},
}

_SCRIPTS = {"te": (0x0C00, 0x0C7F), "kn": (0x0C80, 0x0CFF), "hi": (0x0900, 0x097F)}


def detect_language(text: str) -> str | None:
    """Detect te / kn / hi / en from the script used. None if no letters."""
    counts = {code: sum(lo <= ord(c) <= hi for c in text)
              for code, (lo, hi) in _SCRIPTS.items()}
    counts["en"] = sum(c.isascii() and c.isalpha() for c in text)
    code, n = max(counts.items(), key=lambda kv: kv[1])
    return code if n else None


def language_name(code: str) -> str:
    return LANGUAGES.get(code, LANGUAGES["en"])["name"]


CATEGORIES = ["crop", "irrigation", "soil", "pest", "sustainable"]
CATEGORY_ICONS = {"crop": "🌾", "irrigation": "💧", "soil": "🪱", "pest": "🐛",
                  "sustainable": "♻️"}

UI = {
    "en": {
        "subtitle": "Your Intelligent Sustainable Farming Assistant",
        "welcome": "Namaste! Ask me about crops, irrigation, soil, pests and sustainable farming.",
        "placeholder": "Type your farming question here…",
        "send": "Send",
        "mic": "🎤 Tap to speak your question",
        "voice_hint": "Press the microphone, speak, then press it again to stop.",
        "mic_help": ("Microphone not recording? Click the lock icon in the browser address bar "
                     "and allow the microphone. It works on localhost or an https:// address."),
        "recognized": "We heard (you can correct it before sending):",
        "transcribing": "Listening to your voice…",
        "listen": "🔊 Listen",
        "sources": "Sources",
        "clear": "🗑️ Clear chat",
        "suggested": "Suggested questions",
        "thinking": "Searching the farming documents and preparing an answer…",
        "empty_question": "Please type or speak a question first.",
        "kb_empty": "The knowledge base is not built yet.",
        "language": "Language",
        "auto_speak": "Read answers aloud automatically",
        "auto_send": "Send voice question immediately",
        "topics": "Choose a topic",
        "page": "page",
        "not_found": ("Sorry, the available documents do not contain enough information "
                      "to answer this question. Please contact your nearest Krishi Vigyan "
                      "Kendra (KVK) or agricultural officer."),
        "disclaimer": ("Advice is based only on the agricultural documents in this app's "
                       "knowledge base. It does not diagnose crop diseases or guarantee "
                       "results. For important decisions, consult your local KVK or "
                       "agricultural officer."),
        "crop": "Crop Selection", "irrigation": "Irrigation", "soil": "Soil Management",
        "pest": "Pest Prevention", "sustainable": "Sustainable Farming",
    },
    "te": {
        "subtitle": "మీ తెలివైన సుస్థిర వ్యవసాయ సహాయకుడు",
        "welcome": "నమస్కారం! పంటలు, నీటిపారుదల, నేల, చీడపీడలు, సుస్థిర వ్యవసాయం గురించి అడగండి.",
        "placeholder": "మీ ప్రశ్నను ఇక్కడ టైప్ చేయండి…",
        "send": "పంపండి",
        "mic": "🎤 నొక్కి మీ ప్రశ్న చెప్పండి",
        "voice_hint": "మైక్ నొక్కండి, మాట్లాడండి, ఆపడానికి మళ్ళీ నొక్కండి.",
        "mic_help": ("మైక్ పని చేయడం లేదా? బ్రౌజర్ అడ్రస్ బార్‌లోని తాళం గుర్తును నొక్కి మైక్రోఫోన్‌ను "
                     "అనుమతించండి. ఇది localhost లేదా https:// చిరునామాలో పనిచేస్తుంది."),
        "recognized": "మేము విన్నది (పంపే ముందు సరిచేయవచ్చు):",
        "transcribing": "మీ మాటలు వింటున్నాం…",
        "listen": "🔊 వినండి",
        "sources": "ఆధారాలు",
        "clear": "🗑️ చాట్ తొలగించండి",
        "suggested": "సూచించిన ప్రశ్నలు",
        "thinking": "వ్యవసాయ పత్రాలలో వెతికి సమాధానం సిద్ధం చేస్తున్నాం…",
        "empty_question": "దయచేసి ముందుగా ఒక ప్రశ్న టైప్ చేయండి లేదా చెప్పండి.",
        "kb_empty": "జ్ఞాన భాండారం ఇంకా సిద్ధం కాలేదు.",
        "language": "భాష",
        "auto_speak": "సమాధానాలను ఆటోమేటిక్‌గా చదివి వినిపించు",
        "auto_send": "వాయిస్ ప్రశ్నను వెంటనే పంపు",
        "topics": "ఒక అంశాన్ని ఎంచుకోండి",
        "page": "పేజీ",
        "not_found": ("క్షమించండి, అందుబాటులో ఉన్న పత్రాలలో ఈ ప్రశ్నకు తగిన సమాచారం లేదు. "
                      "దయచేసి మీ సమీప కృషి విజ్ఞాన కేంద్రం (KVK) లేదా వ్యవసాయ అధికారిని సంప్రదించండి."),
        "disclaimer": ("ఈ సలహాలు ఈ యాప్‌లోని వ్యవసాయ పత్రాల ఆధారంగా మాత్రమే. ఇది పంట వ్యాధులను "
                       "నిర్ధారించదు, ఫలితాలకు హామీ ఇవ్వదు. ముఖ్యమైన నిర్ణయాలకు మీ స్థానిక KVK లేదా "
                       "వ్యవసాయ అధికారిని సంప్రదించండి."),
        "crop": "పంట ఎంపిక", "irrigation": "నీటిపారుదల", "soil": "నేల నిర్వహణ",
        "pest": "చీడపీడల నివారణ", "sustainable": "సుస్థిర వ్యవసాయం",
    },
    "kn": {
        "subtitle": "ನಿಮ್ಮ ಬುದ್ಧಿವಂತ ಸುಸ್ಥಿರ ಕೃಷಿ ಸಹಾಯಕ",
        "welcome": "ನಮಸ್ಕಾರ! ಬೆಳೆ, ನೀರಾವರಿ, ಮಣ್ಣು, ಕೀಟ ನಿರ್ವಹಣೆ ಮತ್ತು ಸುಸ್ಥಿರ ಕೃಷಿ ಬಗ್ಗೆ ಕೇಳಿ.",
        "placeholder": "ನಿಮ್ಮ ಪ್ರಶ್ನೆಯನ್ನು ಇಲ್ಲಿ ಟೈಪ್ ಮಾಡಿ…",
        "send": "ಕಳುಹಿಸಿ",
        "mic": "🎤 ಒತ್ತಿ ನಿಮ್ಮ ಪ್ರಶ್ನೆ ಹೇಳಿ",
        "voice_hint": "ಮೈಕ್ ಒತ್ತಿ, ಮಾತನಾಡಿ, ನಿಲ್ಲಿಸಲು ಮತ್ತೆ ಒತ್ತಿ.",
        "mic_help": ("ಮೈಕ್ ಕೆಲಸ ಮಾಡುತ್ತಿಲ್ಲವೇ? ಬ್ರೌಸರ್ ವಿಳಾಸ ಪಟ್ಟಿಯಲ್ಲಿನ ಬೀಗದ ಚಿಹ್ನೆ ಒತ್ತಿ ಮೈಕ್ರೊಫೋನ್‌ಗೆ "
                     "ಅನುಮತಿ ನೀಡಿ. ಇದು localhost ಅಥವಾ https:// ವಿಳಾಸದಲ್ಲಿ ಕೆಲಸ ಮಾಡುತ್ತದೆ."),
        "recognized": "ನಾವು ಕೇಳಿದ್ದು (ಕಳುಹಿಸುವ ಮೊದಲು ಸರಿಪಡಿಸಬಹುದು):",
        "transcribing": "ನಿಮ್ಮ ಧ್ವನಿಯನ್ನು ಕೇಳುತ್ತಿದ್ದೇವೆ…",
        "listen": "🔊 ಕೇಳಿ",
        "sources": "ಮೂಲಗಳು",
        "clear": "🗑️ ಚಾಟ್ ಅಳಿಸಿ",
        "suggested": "ಸೂಚಿಸಿದ ಪ್ರಶ್ನೆಗಳು",
        "thinking": "ಕೃಷಿ ದಾಖಲೆಗಳಲ್ಲಿ ಹುಡುಕಿ ಉತ್ತರ ಸಿದ್ಧಪಡಿಸಲಾಗುತ್ತಿದೆ…",
        "empty_question": "ದಯವಿಟ್ಟು ಮೊದಲು ಒಂದು ಪ್ರಶ್ನೆಯನ್ನು ಟೈಪ್ ಮಾಡಿ ಅಥವಾ ಹೇಳಿ.",
        "kb_empty": "ಜ್ಞಾನ ಭಂಡಾರ ಇನ್ನೂ ಸಿದ್ಧವಾಗಿಲ್ಲ.",
        "language": "ಭಾಷೆ",
        "auto_speak": "ಉತ್ತರಗಳನ್ನು ಸ್ವಯಂಚಾಲಿತವಾಗಿ ಓದಿ ಹೇಳು",
        "auto_send": "ಧ್ವನಿ ಪ್ರಶ್ನೆಯನ್ನು ತಕ್ಷಣ ಕಳುಹಿಸು",
        "topics": "ಒಂದು ವಿಷಯವನ್ನು ಆಯ್ಕೆಮಾಡಿ",
        "page": "ಪುಟ",
        "not_found": ("ಕ್ಷಮಿಸಿ, ಲಭ್ಯವಿರುವ ದಾಖಲೆಗಳಲ್ಲಿ ಈ ಪ್ರಶ್ನೆಗೆ ಸಾಕಷ್ಟು ಮಾಹಿತಿ ಇಲ್ಲ. ದಯವಿಟ್ಟು "
                      "ನಿಮ್ಮ ಹತ್ತಿರದ ಕೃಷಿ ವಿಜ್ಞಾನ ಕೇಂದ್ರ (KVK) ಅಥವಾ ಕೃಷಿ ಅಧಿಕಾರಿಯನ್ನು ಸಂಪರ್ಕಿಸಿ."),
        "disclaimer": ("ಈ ಸಲಹೆಗಳು ಈ ಆ್ಯಪ್‌ನಲ್ಲಿರುವ ಕೃಷಿ ದಾಖಲೆಗಳನ್ನು ಮಾತ್ರ ಆಧರಿಸಿವೆ. ಇದು ಬೆಳೆ "
                       "ರೋಗಗಳನ್ನು ಪತ್ತೆಹಚ್ಚುವುದಿಲ್ಲ ಅಥವಾ ಫಲಿತಾಂಶಕ್ಕೆ ಖಾತರಿ ನೀಡುವುದಿಲ್ಲ. ಮುಖ್ಯ "
                       "ನಿರ್ಧಾರಗಳಿಗೆ ನಿಮ್ಮ ಸ್ಥಳೀಯ KVK ಅಥವಾ ಕೃಷಿ ಅಧಿಕಾರಿಯನ್ನು ಸಂಪರ್ಕಿಸಿ."),
        "crop": "ಬೆಳೆ ಆಯ್ಕೆ", "irrigation": "ನೀರಾವರಿ", "soil": "ಮಣ್ಣು ನಿರ್ವಹಣೆ",
        "pest": "ಕೀಟ ತಡೆಗಟ್ಟುವಿಕೆ", "sustainable": "ಸುಸ್ಥಿರ ಕೃಷಿ",
    },
    "hi": {
        "subtitle": "आपका बुद्धिमान टिकाऊ खेती सहायक",
        "welcome": "नमस्ते! फसल, सिंचाई, मिट्टी, कीट रोकथाम और टिकाऊ खेती के बारे में पूछें।",
        "placeholder": "अपना सवाल यहाँ लिखें…",
        "send": "भेजें",
        "mic": "🎤 दबाकर अपना सवाल बोलें",
        "voice_hint": "माइक दबाएँ, बोलें, रोकने के लिए फिर से दबाएँ।",
        "mic_help": ("माइक रिकॉर्ड नहीं कर रहा? ब्राउज़र के एड्रेस बार में ताले के निशान पर क्लिक करके "
                     "माइक्रोफ़ोन की अनुमति दें। यह localhost या https:// पते पर काम करता है।"),
        "recognized": "हमने यह सुना (भेजने से पहले सुधार सकते हैं):",
        "transcribing": "आपकी आवाज़ सुनी जा रही है…",
        "listen": "🔊 सुनें",
        "sources": "स्रोत",
        "clear": "🗑️ चैट साफ़ करें",
        "suggested": "सुझाए गए सवाल",
        "thinking": "कृषि दस्तावेज़ों में खोजकर जवाब तैयार किया जा रहा है…",
        "empty_question": "कृपया पहले कोई सवाल लिखें या बोलें।",
        "kb_empty": "ज्ञान भंडार अभी तैयार नहीं है।",
        "language": "भाषा",
        "auto_speak": "जवाब अपने आप पढ़कर सुनाएँ",
        "auto_send": "आवाज़ वाला सवाल तुरंत भेजें",
        "topics": "एक विषय चुनें",
        "page": "पृष्ठ",
        "not_found": ("माफ़ कीजिए, उपलब्ध दस्तावेज़ों में इस सवाल के लिए पर्याप्त जानकारी नहीं है। "
                      "कृपया अपने नज़दीकी कृषि विज्ञान केंद्र (KVK) या कृषि अधिकारी से संपर्क करें।"),
        "disclaimer": ("ये सलाह केवल इस ऐप के कृषि दस्तावेज़ों पर आधारित है। यह फसल रोगों का निदान "
                       "नहीं करता और परिणाम की गारंटी नहीं देता। महत्वपूर्ण निर्णयों के लिए अपने "
                       "स्थानीय KVK या कृषि अधिकारी से संपर्क करें।"),
        "crop": "फसल चयन", "irrigation": "सिंचाई", "soil": "मिट्टी प्रबंधन",
        "pest": "कीट रोकथाम", "sustainable": "टिकाऊ खेती",
    },
}

SUGGESTED = {
    "crop": {
        "en": ["Which crops are suitable for red soil?",
               "What factors should I consider before selecting a crop?"],
        "te": ["ఎర్ర నేలకు ఏ పంటలు అనుకూలం?",
               "పంటను ఎంచుకునే ముందు ఏ విషయాలు పరిగణించాలి?"],
        "kn": ["ಕೆಂಪು ಮಣ್ಣಿಗೆ ಯಾವ ಬೆಳೆಗಳು ಸೂಕ್ತ?",
               "ಬೆಳೆ ಆಯ್ಕೆ ಮಾಡುವ ಮೊದಲು ಯಾವ ಅಂಶಗಳನ್ನು ಗಮನಿಸಬೇಕು?"],
        "hi": ["लाल मिट्टी के लिए कौन-सी फसलें उपयुक्त हैं?",
               "फसल चुनने से पहले किन बातों का ध्यान रखना चाहिए?"],
    },
    "irrigation": {
        "en": ["What are the advantages of drip irrigation?",
               "How can farmers reduce water wastage?"],
        "te": ["బిందు సేద్యం వల్ల లాభాలు ఏమిటి?",
               "రైతులు నీటి వృథాను ఎలా తగ్గించవచ్చు?"],
        "kn": ["ಹನಿ ನೀರಾವರಿಯ ಅನುಕೂಲಗಳೇನು?",
               "ರೈತರು ನೀರಿನ ಪೋಲನ್ನು ಹೇಗೆ ಕಡಿಮೆ ಮಾಡಬಹುದು?"],
        "hi": ["ड्रिप सिंचाई के क्या फ़ायदे हैं?",
               "किसान पानी की बर्बादी कैसे कम कर सकते हैं?"],
    },
    "soil": {
        "en": ["How can I improve soil fertility?",
               "What is the importance of organic manure?"],
        "te": ["నేల సారాన్ని ఎలా పెంచుకోవచ్చు?",
               "సేంద్రియ ఎరువు ప్రాముఖ్యత ఏమిటి?"],
        "kn": ["ಮಣ್ಣಿನ ಫಲವತ್ತತೆಯನ್ನು ಹೇಗೆ ಹೆಚ್ಚಿಸಬಹುದು?",
               "ಸಾವಯವ ಗೊಬ್ಬರದ ಮಹತ್ವವೇನು?"],
        "hi": ["मिट्टी की उर्वरता कैसे बढ़ाएँ?",
               "जैविक खाद का क्या महत्व है?"],
    },
    "pest": {
        "en": ["What are sustainable ways to prevent crop pests?",
               "What integrated pest management practices are recommended?"],
        "te": ["పంటలకు చీడపీడలు రాకుండా సుస్థిర పద్ధతులు ఏమిటి?",
               "సమగ్ర సస్యరక్షణ (IPM) పద్ధతులు ఏమిటి?"],
        "kn": ["ಬೆಳೆಗಳಿಗೆ ಕೀಟಗಳನ್ನು ತಡೆಯಲು ಸುಸ್ಥಿರ ವಿಧಾನಗಳು ಯಾವುವು?",
               "ಸಮಗ್ರ ಕೀಟ ನಿರ್ವಹಣೆಯ (IPM) ಶಿಫಾರಸು ಮಾಡಿದ ಕ್ರಮಗಳು ಯಾವುವು?"],
        "hi": ["फसलों में कीटों को रोकने के टिकाऊ तरीके क्या हैं?",
               "एकीकृत कीट प्रबंधन (IPM) के कौन-से तरीके सुझाए गए हैं?"],
    },
    "sustainable": {
        "en": ["What is crop rotation?", "What are the benefits of organic farming?"],
        "te": ["పంట మార్పిడి అంటే ఏమిటి?", "సేంద్రియ వ్యవసాయం వల్ల లాభాలు ఏమిటి?"],
        "kn": ["ಬೆಳೆ ಪರಿವರ್ತನೆ ಎಂದರೇನು?", "ಸಾವಯವ ಕೃಷಿಯ ಪ್ರಯೋಜನಗಳೇನು?"],
        "hi": ["फसल चक्र क्या है?", "जैविक खेती के क्या फ़ायदे हैं?"],
    },
}


def t(lang: str, key: str) -> str:
    """Translated UI string, falling back to English."""
    return UI.get(lang, UI["en"]).get(key) or UI["en"].get(key, key)


def suggestions(lang: str, category: str) -> list[str]:
    cat = SUGGESTED.get(category, {})
    return cat.get(lang) or cat.get("en", [])
