"""Multilingual sentence embeddings (sentence-transformers)."""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class Embedder:
    """Lazily loads the model the first time it is needed (download ~470 MB once)."""

    def __init__(self, model_name: str, max_seq_length: int | None = None):
        self.model_name = model_name
        self.max_seq_length = max_seq_length
        self._model = None

    @property
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer

            log.info("Loading embedding model %s", self.model_name)
            self._model = SentenceTransformer(self.model_name)
            if self.max_seq_length:
                self._model.max_seq_length = self.max_seq_length
        return self._model

    def embed_documents(self, texts: list[str], batch_size: int = 32,
                        show_progress: bool = True) -> list[list[float]]:
        vectors = self.model.encode(texts, batch_size=batch_size,
                                    show_progress_bar=show_progress,
                                    normalize_embeddings=True,
                                    convert_to_numpy=True)
        return vectors.tolist()

    def embed_query(self, text: str) -> list[float]:
        return self.model.encode([text], normalize_embeddings=True,
                                 convert_to_numpy=True)[0].tolist()
