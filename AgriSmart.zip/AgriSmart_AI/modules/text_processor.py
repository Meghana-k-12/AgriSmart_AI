"""Clean page text and split it into overlapping chunks (one page at a time,
so every chunk keeps an exact page number)."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from modules.document_loader import Page


@dataclass
class Chunk:
    id: str
    text: str
    metadata: dict


_PAGE_NUMBER_LINE = re.compile(r"^\s*(page\s*)?\d{1,4}\s*$", re.IGNORECASE)


def clean_text(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = text.replace("\u00ad", "")                        # soft hyphens
    text = re.sub("[\uf000-\uf8ff]", " ", text)              # private-use glyphs (bullets)
    text = re.sub(r"\(cid:\d+\)", " ", text)                 # unmapped glyph placeholders
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)             # re-join hyphenated words
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln and not _PAGE_NUMBER_LINE.match(ln)]
    text = "\n".join(lines)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\.{4,}", "...", text)                     # dotted TOC leaders
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


_SEPARATORS = ["\n\n", "\n", ". ", "। ", "; ", ", ", " "]


def _split(text: str, size: int, seps: list[str]) -> list[str]:
    """Recursively split text into pieces no longer than size."""
    if len(text) <= size:
        return [text]
    for sep in seps:
        if sep in text:
            parts = text.split(sep)
            pieces = [p + sep for p in parts[:-1]] + [parts[-1]]
            out = []
            for p in pieces:
                out.extend(_split(p, size, seps[seps.index(sep) + 1:]) if len(p) > size else [p])
            return [p for p in out if p]
    return [text[i:i + size] for i in range(0, len(text), size)]


def split_text(text: str, chunk_size: int = 800, overlap: int = 150) -> list[str]:
    """Greedy merge of small pieces into ~chunk_size chunks with overlap."""
    pieces = _split(text, chunk_size, _SEPARATORS)
    chunks: list[str] = []
    current = ""
    for piece in pieces:
        if len(current) + len(piece) <= chunk_size:
            current += piece
            continue
        if current.strip():
            chunks.append(current.strip())
        # start the next chunk with the tail of the previous one (overlap),
        # cut at a word boundary
        tail = current[-overlap:] if overlap else ""
        if " " in tail:
            tail = tail[tail.index(" ") + 1:]
        current = tail + piece
        if len(current) > chunk_size:           # overlap + piece too long
            current = piece
    if current.strip():
        chunks.append(current.strip())
    return chunks


_TOC_LINE = re.compile(r"(\.\.\.|…)\s*\d{1,4}\s*$|\s\d{1,3}\s*$")


def is_low_content(text: str) -> bool:
    """Table-of-contents blocks and bare title pages: retrieved often, answer nothing."""
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(text) < 120 and not re.search(r"[.!?।]", text):
        return True                                   # title / heading only
    if len(lines) >= 6:
        toc = sum(bool(_TOC_LINE.search(ln)) for ln in lines)
        head = " ".join(lines[:3]).lower()
        if toc / len(lines) > 0.5 and ("content" in head or "..." in text):
            return True
    return False


def chunk_pages(pages: list[Page], chunk_size: int = 800, overlap: int = 150,
                min_chunk_chars: int = 40) -> list[Chunk]:
    chunks: list[Chunk] = []
    for page in pages:
        text = clean_text(page.text)
        for i, piece in enumerate(split_text(text, chunk_size, overlap)):
            if len(piece) < min_chunk_chars or is_low_content(piece):
                continue
            chunks.append(Chunk(
                id=f"{page.source}::p{page.page}::c{i}",
                text=piece,
                metadata={"source": page.source, "title": page.title,
                          "publisher": page.publisher,
                          "page": page.page, "language": page.language,
                          "chunk": i},
            ))
    return chunks
