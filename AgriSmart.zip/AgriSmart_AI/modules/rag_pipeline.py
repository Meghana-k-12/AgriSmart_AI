"""
Retrieval-Augmented Generation: question -> relevant chunks -> Gemini -> grounded answer.

Multilingual retrieval
----------------------
paraphrase-multilingual-MiniLM-L12-v2 was trained on ~50 languages including
Hindi and English, but NOT Telugu or Kannada. Telugu/Kannada questions
therefore match English pages poorly. To fix that, non-English questions are
also translated to English (one quick Gemini call) and BOTH the original and
the English version are searched; results are merged. The original question
still matches the Kannada UAS Bangalore pages directly.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field

from modules.language_handler import language_name, t

log = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are AgriSmart AI, a careful agricultural advisor for Indian farmers.
You answer ONLY from the numbered source passages you are given, which come from trusted
agricultural documents (for example the TNAU Crop Production Guide, the UAS Bangalore
Package of Practices, the FAO organic agriculture training manual, and the Handbook on
Agroecology published by Focus on the Global South). Always name a document exactly as
given in the passage header; never attribute a passage to a different organisation.

Rules:
1. Use simple, practical, farmer-friendly words and short sentences that sound natural when
   read aloud. Avoid technical jargon; if a technical term is needed, explain it briefly.
2. Every fact taken from a passage must end with its citation, e.g. [S2]. Never cite a
   passage that does not support the statement.
3. NEVER invent fertilizer quantities, pesticide names or dosages, crop yields, seed rates or
   irrigation schedules. Give a number only if it appears in a cited passage, copy it exactly
   with its unit, and say which crop/region it applies to.
4. Keep crop variety names, chemical names and units exactly as written in the source
   (you may add the local-language word in brackets). Do not change the meaning of any
   technical instruction when translating.
5. Clearly separate document-supported facts from general guidance. General guidance must be
   common-sense, non-numerical, and marked as general.
6. Mention that recommendations depend on location, season, soil type, rainfall and water
   availability. Note when a source is region-specific (TNAU = Tamil Nadu, UAS Bangalore =
   southern Karnataka).
7. For pesticide/fertilizer use or other important decisions, advise checking with the local
   Krishi Vigyan Kendra (KVK) or agricultural officer.
8. You do not diagnose crop diseases and you never guarantee results.
9. If the passages do not contain enough information to answer, your reply must start with
   the line NOT_FOUND, followed by one or two sentences (in the answer language) saying the
   available knowledge base does not have enough information and suggesting the local KVK.
   Do not answer from your own general knowledge in that case.
"""

ANSWER_FORMAT = """Write the whole answer in {lang}.
Use this structure (translate the headings into {lang}):
**Answer:** 2–3 sentence direct answer.
**From the documents:** 2–6 bullet points, each ending with its citation like [S1].
**General guidance:** (optional) 1–2 bullets of general, non-numerical advice, clearly not from the documents.
**Note:** one line that advice depends on location, season, soil, rainfall and water, and when to contact the local KVK.
"""


@dataclass
class RAGAnswer:
    question: str
    language: str
    answer: str
    status: str                     # ok | not_found | retrieval_only | error | empty
    sources: list = field(default_factory=list)   # [{"title", "source", "pages":[..]}]
    hits: list = field(default_factory=list)
    search_queries: list = field(default_factory=list)
    error: str | None = None


def format_context(hits: list[dict]) -> str:
    blocks = []
    for i, h in enumerate(hits, 1):
        m = h["metadata"]
        pub = f" ({m['publisher']})" if m.get("publisher") else ""
        blocks.append(f"[S{i}] {m.get('title')}{pub} — file {m.get('source')}, "
                      f"PDF page {m.get('page')}\n{h['text']}")
    return "\n\n".join(blocks)


def build_prompt(question: str, lang_code: str, hits: list[dict]) -> str:
    return (f"Source passages:\n\n{format_context(hits)}\n\n"
            f"Farmer's question: {question}\n\n"
            + ANSWER_FORMAT.format(lang=language_name(lang_code)))


def cited_indices(answer: str, n_hits: int) -> list[int]:
    nums = {int(x) for x in re.findall(r"\[S(\d+)\]", answer)}
    return sorted(i for i in nums if 1 <= i <= n_hits)


def group_sources(hits: list[dict]) -> list[dict]:
    grouped: dict[str, dict] = {}
    for h in hits:
        m = h["metadata"]
        g = grouped.setdefault(m["source"], {"title": m.get("title", m["source"]),
                                             "publisher": m.get("publisher", ""),
                                             "source": m["source"], "pages": set()})
        g["pages"].add(int(m["page"]))
    return [{**g, "pages": sorted(g["pages"])} for g in grouped.values()]


class RAGPipeline:
    def __init__(self, embedder, store, llm=None, top_k: int = 6,
                 min_similarity: float = 0.25, translate_query: bool = True,
                 similarity_floor: float = 0.15, fallback_k: int = 3):
        """
        Similarity = cosine similarity (ChromaDB cosine distance converted back with
        1 - distance; embeddings are L2-normalised), range -1..1.
        * hits >= min_similarity are used normally;
        * if none pass, the best `fallback_k` hits >= similarity_floor are still given to
          Gemini, which must answer NOT_FOUND if they are irrelevant. This avoids false
          "not found" answers when a threshold is slightly too strict.
        """
        self.embedder = embedder
        self.store = store
        self.llm = llm
        self.top_k = top_k
        self.min_similarity = min_similarity
        self.similarity_floor = min(similarity_floor, min_similarity)
        self.fallback_k = fallback_k
        self.translate_query = translate_query

    # ------------------------------------------------------------------ retrieval
    def search_queries_for(self, question: str, lang: str) -> list[str]:
        queries = [question]
        if lang != "en" and self.translate_query and self.llm is not None:
            try:
                english = self.llm.translate_to_english(question)
                if english and english.lower() != question.lower():
                    queries.append(english)
            except Exception as exc:          # retrieval still works without it
                log.warning("Query translation failed: %s", exc)
        return queries

    def retrieve(self, question: str, lang: str) -> tuple[list[dict], list[str]]:
        queries = self.search_queries_for(question, lang)
        merged: dict[str, dict] = {}
        for q in queries:
            for h in self.store.query(self.embedder.embed_query(q), k=self.top_k):
                if h["id"] not in merged or h["similarity"] > merged[h["id"]]["similarity"]:
                    merged[h["id"]] = {**h, "matched_query": q}
        ranked = sorted(merged.values(), key=lambda h: h["similarity"], reverse=True)
        hits = [h for h in ranked if h["similarity"] >= self.min_similarity][: self.top_k]
        if not hits and self.llm is not None:      # weak-evidence fallback (Gemini decides)
            hits = [h for h in ranked if h["similarity"] >= self.similarity_floor][: self.fallback_k]
            for h in hits:
                h["weak_match"] = True
        return hits, queries

    # ------------------------------------------------------------------ answer
    def answer(self, question: str, lang: str = "en") -> RAGAnswer:
        question = (question or "").strip()
        if not question:
            return RAGAnswer(question, lang, t(lang, "empty_question"), "empty")

        try:
            hits, queries = self.retrieve(question, lang)
        except Exception as exc:
            log.exception("Retrieval failed")
            return RAGAnswer(question, lang, f"Search failed: {exc}", "error", error=str(exc))

        if not hits:
            return RAGAnswer(question, lang, t(lang, "not_found"), "not_found",
                             search_queries=queries)

        if self.llm is None:   # no API key: show what was retrieved, honestly labelled
            return RAGAnswer(question, lang,
                             "Gemini is not configured, so here are the most relevant "
                             "passages from the documents (no AI summary).",
                             "retrieval_only", group_sources(hits), hits, queries)

        try:
            text = self.llm.generate(build_prompt(question, lang, hits), system=SYSTEM_PROMPT)
        except Exception as exc:
            return RAGAnswer(question, lang, str(exc), "error", group_sources(hits), hits,
                             queries, error=getattr(exc, "kind", "other"))

        if text.lstrip().upper().startswith("NOT_FOUND"):
            body = text.lstrip()[len("NOT_FOUND"):].strip(" :\n") or t(lang, "not_found")
            return RAGAnswer(question, lang, body, "not_found", [], hits, queries)

        idx = cited_indices(text, len(hits))
        used = [hits[i - 1] for i in idx] if idx else hits
        return RAGAnswer(question, lang, text, "ok", group_sources(used), hits, queries)
