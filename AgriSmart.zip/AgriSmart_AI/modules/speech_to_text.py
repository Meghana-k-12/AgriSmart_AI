"""
Speech-to-text for farmer questions.

Backends
  whisper : OpenAI Whisper running locally (pip install openai-whisper).
            Free, offline after the model download. Supports en/hi/te/kn, but
            Telugu and Kannada accuracy is noticeably weaker than Hindi/English,
            especially with the small models.
  gemini  : Sends the recording to Gemini (same GOOGLE_API_KEY). Usually more
            accurate for Telugu and Kannada; needs internet.

The browser recording from Streamlit's st.audio_input is a WAV file. We decode
WAV with the standard library + numpy, so Whisper does not need ffmpeg here.
"""

from __future__ import annotations

import io
import logging
import wave

import numpy as np

from modules.language_handler import LANGUAGES

log = logging.getLogger(__name__)

_WHISPER_CACHE: dict = {}


class STTError(Exception):
    pass


def wav_to_float32_16k(audio_bytes: bytes) -> np.ndarray:
    """Decode PCM WAV bytes to mono float32 at 16 kHz (what Whisper expects)."""
    try:
        with wave.open(io.BytesIO(audio_bytes)) as wf:
            channels, width, rate = wf.getnchannels(), wf.getsampwidth(), wf.getframerate()
            frames = wf.readframes(wf.getnframes())
    except (wave.Error, EOFError) as exc:
        raise STTError(f"Could not read the recording ({exc}). Please record again.") from exc

    dtype = {1: np.uint8, 2: np.int16, 4: np.int32}.get(width)
    if dtype is None:
        raise STTError(f"Unsupported audio sample width: {width} bytes")
    audio = np.frombuffer(frames, dtype=dtype).astype(np.float32)
    if width == 1:
        audio = (audio - 128.0) / 128.0
    else:
        audio /= float(np.iinfo(dtype).max)
    if channels > 1:
        audio = audio.reshape(-1, channels).mean(axis=1)
    if rate != 16000 and len(audio):
        n_out = int(len(audio) * 16000 / rate)
        audio = np.interp(np.linspace(0, len(audio) - 1, n_out),
                          np.arange(len(audio)), audio).astype(np.float32)
    return audio


def _check_not_silent(audio: np.ndarray) -> None:
    if len(audio) < 16000 * 0.4:
        raise STTError("The recording is too short. Hold the microphone and speak clearly.")
    if float(np.sqrt(np.mean(audio ** 2))) < 0.003:
        raise STTError("No voice was detected. Check that the microphone is allowed "
                       "in the browser and speak a little louder.")


def transcribe_whisper(audio_bytes: bytes, lang: str, model_size: str = "small") -> str:
    try:
        import whisper
    except ImportError as exc:
        raise STTError("Whisper is not installed (pip install openai-whisper), or choose "
                       "the Gemini speech option in the sidebar.") from exc
    audio = wav_to_float32_16k(audio_bytes)
    _check_not_silent(audio)
    if model_size not in _WHISPER_CACHE:
        log.info("Loading Whisper model %s", model_size)
        _WHISPER_CACHE[model_size] = whisper.load_model(model_size)
    model = _WHISPER_CACHE[model_size]
    result = model.transcribe(audio, language=LANGUAGES[lang]["whisper"],
                              task="transcribe", fp16=False)
    return (result.get("text") or "").strip()


def transcribe_gemini(audio_bytes: bytes, lang: str, llm) -> str:
    if llm is None:
        raise STTError("Gemini speech recognition needs GOOGLE_API_KEY in the .env file.")
    _check_not_silent(wav_to_float32_16k(audio_bytes))
    try:
        return llm.transcribe(audio_bytes, "audio/wav", LANGUAGES[lang]["name"])
    except Exception as exc:
        raise STTError(str(exc)) from exc


def transcribe(audio_bytes: bytes, lang: str, backend: str = "whisper", llm=None,
               whisper_model: str = "small") -> str:
    if not audio_bytes:
        raise STTError("No audio was received from the microphone.")
    if backend == "gemini":
        text = transcribe_gemini(audio_bytes, lang, llm)
    else:
        text = transcribe_whisper(audio_bytes, lang, whisper_model)
    if not text:
        raise STTError("Sorry, the speech could not be understood. Please try again.")
    return text
