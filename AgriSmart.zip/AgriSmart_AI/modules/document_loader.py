"""
Load every PDF in data/ page by page, keeping file name, title and page number.

* Uses PyMuPDF (fitz). If PyMuPDF is missing, falls back to pdfplumber.
* Text drawn in the legacy Nudi Kannada font is converted to Unicode
  Kannada (see kannada_nudi.py), span by span, so English words, numbers and
  e-mail addresses on the same page are not corrupted.
* A file that cannot be opened is reported and skipped; it never stops the
  other files from loading.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

from modules.kannada_nudi import is_nudi_font, nudi_to_unicode

log = logging.getLogger(__name__)


@dataclass
class Page:
    text: str
    source: str        # file name, e.g. "AGRICULTURE_2.pdf"
    title: str         # human-readable document title
    page: int          # 1-based PDF page number
    language: str      # "en", "kn", ...
    publisher: str = ""


@dataclass
class LoadReport:
    loaded: dict = field(default_factory=dict)    # file -> {pages, text_pages, chars}
    failed: dict = field(default_factory=dict)    # file -> error message
    warnings: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Titles
# ---------------------------------------------------------------------------
def _load_source_names(sources_file: Path) -> list[dict]:
    if not sources_file.exists():
        return []
    try:
        return json.loads(sources_file.read_text(encoding="utf-8")).get("documents", [])
    except Exception as exc:  # malformed JSON must not break loading
        log.warning("Could not read %s: %s", sources_file, exc)
        return []


_BAD_META_TITLE = re.compile(
    r"\.(cdr|docx?|indd|qxd|pdf|pub|ai|psd|xlsx?|pptx?|rtf|txt)$|^untitled|^microsoft word|^slide \d",
    re.IGNORECASE)


def usable_meta_title(meta_title: str | None) -> str | None:
    """PDF metadata titles are often design-file names (e.g. 'Agriculture Science.cdr')."""
    if not meta_title:
        return None
    meta_title = meta_title.strip()
    if len(meta_title) < 4 or _BAD_META_TITLE.search(meta_title):
        return None
    return meta_title


def _resolve_title(pdf_path: Path, names: list[dict], meta_title: str | None):
    """Return (title, language, publisher) — sources.json first, then metadata, then file name."""
    for entry in names:
        if entry.get("match", "").lower() in pdf_path.name.lower():
            return (entry.get("title", pdf_path.stem), entry.get("language"),
                    entry.get("publisher", ""))
    title = usable_meta_title(meta_title)
    if title:
        return title, None, ""
    return pdf_path.stem.replace("_", " ").replace("-", " "), None, ""


# ---------------------------------------------------------------------------
# Extraction backends
# ---------------------------------------------------------------------------
def _span_text(text: str, font: str) -> str:
    return nudi_to_unicode(text) if is_nudi_font(font) else text


def _pages_pymupdf(path: Path):
    import fitz  # PyMuPDF

    with fitz.open(path) as doc:
        meta_title = (doc.metadata or {}).get("title")
        pages = []
        for page in doc:
            blocks = []
            for block in page.get_text("dict").get("blocks", []):
                if block.get("type") != 0:      # 0 = text, 1 = image
                    continue
                lines = []
                for line in block.get("lines", []):
                    lines.append("".join(_span_text(s.get("text", ""), s.get("font", ""))
                                         for s in line.get("spans", [])))
                blocks.append("\n".join(lines))
            pages.append("\n\n".join(blocks))
        return pages, meta_title


def _pages_pdfplumber(path: Path):
    import pdfplumber

    with pdfplumber.open(path) as pdf:
        meta_title = (pdf.metadata or {}).get("Title")
        pages = []
        for page in pdf.pages:
            words = page.extract_words(extra_attrs=["fontname"], keep_blank_chars=False)
            lines: dict[int, list[str]] = {}
            for w in words:
                key = round(w["top"] / 3)       # group words on the same line
                lines.setdefault(key, []).append(_span_text(w["text"], w["fontname"]))
            pages.append("\n".join(" ".join(ws) for _, ws in sorted(lines.items())))
        return pages, meta_title


def _extract(path: Path):
    try:
        import fitz  # noqa: F401
        return _pages_pymupdf(path)
    except ImportError:
        return _pages_pdfplumber(path)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def find_pdfs(data_dir: Path) -> list[Path]:
    return sorted(p for p in Path(data_dir).glob("*") if p.suffix.lower() == ".pdf")


def _guess_language(text: str) -> str:
    kn = sum(0x0C80 <= ord(c) <= 0x0CFF for c in text)
    te = sum(0x0C00 <= ord(c) <= 0x0C7F for c in text)
    hi = sum(0x0900 <= ord(c) <= 0x097F for c in text)
    latin = sum(c.isascii() and c.isalpha() for c in text)
    best = max([("kn", kn), ("te", te), ("hi", hi), ("en", latin)], key=lambda x: x[1])
    return best[0] if best[1] else "en"


def load_documents(data_dir: Path, sources_file: Path | None = None,
                   min_chars: int = 40, progress=None) -> tuple[list[Page], LoadReport]:
    """Return all non-empty pages from every PDF in data_dir plus a report."""
    report = LoadReport()
    pdfs = find_pdfs(data_dir)
    if not pdfs:
        report.warnings.append(f"No PDF files found in {data_dir}")
        return [], report

    names = _load_source_names(sources_file) if sources_file else []
    out: list[Page] = []
    for i, path in enumerate(pdfs, 1):
        if progress:
            progress(f"Reading {path.name} ({i}/{len(pdfs)})")
        try:
            raw_pages, meta_title = _extract(path)
        except Exception as exc:
            report.failed[path.name] = f"{type(exc).__name__}: {exc}"
            log.error("Failed to read %s: %s", path.name, exc)
            continue

        title, lang, publisher = _resolve_title(path, names, meta_title)
        kept, chars = 0, 0
        for page_no, text in enumerate(raw_pages, 1):
            text = (text or "").strip()
            if len(text) < min_chars:
                continue
            out.append(Page(text=text, source=path.name, title=title, page=page_no,
                            language=lang or _guess_language(text), publisher=publisher))
            kept += 1
            chars += len(text)

        report.loaded[path.name] = {"title": title, "publisher": publisher,
                                    "meta_title": meta_title or "", "pages": len(raw_pages),
                                    "text_pages": kept, "chars": chars}
        if kept == 0:
            report.warnings.append(
                f"{path.name}: no extractable text (scanned PDF? needs OCR)")
        elif kept < 0.5 * len(raw_pages):
            report.warnings.append(
                f"{path.name}: only {kept}/{len(raw_pages)} pages had text")
    return out, report
