"""ChromaDB persistence plus a manifest that records what has been indexed,
so the PDFs are only re-embedded when they (or the settings) change."""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Manifest (detects changed PDFs / settings)
# ---------------------------------------------------------------------------
def file_fingerprint(path: Path) -> str:
    h = hashlib.sha1()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def build_manifest(pdfs: list[Path], settings: dict) -> dict:
    return {"files": {p.name: file_fingerprint(p) for p in pdfs}, "settings": settings}


def read_manifest(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def write_manifest(path: Path, manifest: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")


def manifest_changes(old: dict | None, new: dict) -> list[str]:
    """Human-readable list of reasons a rebuild is needed (empty = up to date)."""
    if not old:
        return ["no existing index"]
    reasons = []
    if old.get("settings") != new["settings"]:
        reasons.append("chunking/embedding settings changed")
    old_f, new_f = old.get("files", {}), new["files"]
    for name in new_f.keys() - old_f.keys():
        reasons.append(f"new file: {name}")
    for name in old_f.keys() - new_f.keys():
        reasons.append(f"removed file: {name}")
    for name in new_f.keys() & old_f.keys():
        if new_f[name] != old_f[name]:
            reasons.append(f"changed file: {name}")
    return reasons


# ---------------------------------------------------------------------------
# Chroma wrapper
# ---------------------------------------------------------------------------
class VectorStore:
    def __init__(self, path: Path, collection_name: str):
        import chromadb
        from chromadb.config import Settings

        Path(path).mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(
            path=str(path), settings=Settings(anonymized_telemetry=False))
        self.name = collection_name
        self.collection = self._get_or_create()

    def _get_or_create(self):
        return self.client.get_or_create_collection(
            name=self.name, metadata={"hnsw:space": "cosine"})

    def count(self) -> int:
        return self.collection.count()

    def reset(self) -> None:
        try:
            self.client.delete_collection(self.name)
        except Exception:
            pass  # did not exist yet
        self.collection = self._get_or_create()

    def add(self, ids, texts, embeddings, metadatas, batch_size: int = 1000) -> None:
        for start in range(0, len(ids), batch_size):
            end = start + batch_size
            self.collection.add(ids=ids[start:end], documents=texts[start:end],
                                embeddings=embeddings[start:end],
                                metadatas=metadatas[start:end])

    def query(self, embedding: list[float], k: int = 6) -> list[dict]:
        if self.count() == 0:
            return []
        res = self.collection.query(query_embeddings=[embedding],
                                    n_results=min(k, self.count()),
                                    include=["documents", "metadatas", "distances"])
        hits = []
        for i, doc, meta, dist in zip(res["ids"][0], res["documents"][0],
                                      res["metadatas"][0], res["distances"][0]):
            hits.append({"id": i, "text": doc, "metadata": meta,
                         "similarity": round(1.0 - float(dist), 4)})
        return hits

    def documents_summary(self) -> dict:
        """Chunks per document title (for the sidebar)."""
        if self.count() == 0:
            return {}
        metas = self.collection.get(include=["metadatas"])["metadatas"]
        summary: dict[str, int] = {}
        for m in metas:
            summary[m.get("title", "?")] = summary.get(m.get("title", "?"), 0) + 1
        return summary
