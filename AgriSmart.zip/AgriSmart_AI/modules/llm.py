"""Gemini client (google-genai SDK) with friendly error messages."""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)


class LLMError(Exception):
    """kind: auth | quota | model | network | config | other"""

    def __init__(self, message: str, kind: str = "other"):
        super().__init__(message)
        self.kind = kind


# Tried in order when the configured model is unavailable for this API key.
# Google limits the 2.5 models to users who already used them; new projects
# should use the 3.x models (see README, "Gemini model").
FALLBACK_MODELS = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"]

_MODEL_UNAVAILABLE = ("not found", "not available", "not supported", "no longer",
                      "is not allowed", "deprecated", "unsupported model")


def _classify(exc: Exception) -> LLMError:
    code = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    text = str(exc)
    low = text.lower()
    if "api key" in low or "api_key" in low:
        return LLMError("Gemini rejected the API key. Check GOOGLE_API_KEY in your .env file.",
                        "auth")
    if code == 404 or ("model" in low and any(w in low for w in _MODEL_UNAVAILABLE)):
        return LLMError(f"Gemini model unavailable for this key: {text[:160]}", "model")
    if code in (401, 403) or "permission" in low:
        return LLMError("Gemini refused the request (permission). Check that the API key is "
                        "from Google AI Studio and the Gemini API is enabled.", "auth")
    if code == 429 or "quota" in low or "resource_exhausted" in low or "rate limit" in low:
        return LLMError("Gemini usage limit reached. Wait a minute and try again.", "quota")
    name = type(exc).__name__.lower()
    if any(w in name for w in ("connect", "timeout", "network")) or "getaddrinfo" in low:
        return LLMError("Could not reach Gemini. Check your internet connection.", "network")
    return LLMError(f"Gemini error: {text[:300]}", "other")


class GeminiClient:
    def __init__(self, api_key: str, model: str = "gemini-3.8-flash",
                 temperature: float = 0.2):
        if not api_key or api_key.startswith("your_"):
            raise LLMError("GOOGLE_API_KEY is missing. Add it to the .env file.", "config")
        try:
            from google import genai
            from google.genai import types
        except ImportError as exc:
            raise LLMError("The google-genai package is not installed "
                           "(pip install google-genai).", "config") from exc
        self._types = types
        self.client = genai.Client(api_key=api_key)
        # GEMINI_MODEL may be one name or a comma-separated preference list
        preferred = [m.strip() for m in model.split(",") if m.strip()]
        self.models = preferred + [m for m in FALLBACK_MODELS if m not in preferred]
        self.model = self.models[0]
        self.temperature = temperature

    def _call(self, contents, config):
        """generate_content with automatic fallback to the next model if one is unavailable."""
        last = None
        for name in [self.model] + [m for m in self.models if m != self.model]:
            try:
                resp = self.client.models.generate_content(model=name, contents=contents,
                                                           config=config)
                if name != self.model:
                    log.warning("Gemini model %s unavailable; using %s", self.model, name)
                    self.model = name           # remember the working model
                return resp
            except Exception as exc:
                err = _classify(exc)
                if err.kind != "model":
                    raise err from exc
                last = err
        raise LLMError("None of the Gemini models are available for this API key "
                       f"({', '.join(self.models)}). Set GEMINI_MODEL in .env to a model "
                       f"listed in Google AI Studio. Last error: {last}", "model")

    def generate(self, prompt: str, system: str | None = None,
                 temperature: float | None = None) -> str:
        resp = self._call(prompt, self._types.GenerateContentConfig(
            system_instruction=system,
            temperature=self.temperature if temperature is None else temperature))
        text = (getattr(resp, "text", None) or "").strip()
        if not text:
            raise LLMError("Gemini returned an empty answer (it may have been blocked "
                           "by safety filters). Try rephrasing the question.", "other")
        return text

    def translate_to_english(self, text: str) -> str:
        """Short, literal translation of a farmer's question for retrieval."""
        prompt = ("Translate this farmer's question into simple English for searching "
                  "agricultural manuals. Keep crop names, pest names and numbers. "
                  "Output only the translation.\n\n" + text)
        return self.generate(prompt, temperature=0.0).splitlines()[0].strip()

    def transcribe(self, audio_bytes: bytes, mime_type: str, language: str) -> str:
        prompt = (f"Transcribe this audio exactly as spoken. The speaker uses {language}. "
                  f"Write it in the {language} script. Output only the transcript, "
                  "nothing else. If there is no speech, output an empty line.")
        resp = self._call(
            [self._types.Part.from_bytes(data=audio_bytes, mime_type=mime_type), prompt],
            self._types.GenerateContentConfig(temperature=0.0))
        return (getattr(resp, "text", None) or "").strip()
