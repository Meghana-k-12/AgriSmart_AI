"""
Text-to-speech for answers.

Backends
  google_cloud : Google Cloud Text-to-Speech (official API). Needs a Google Cloud
                 project with the API enabled and GOOGLE_APPLICATION_CREDENTIALS
                 pointing to a service-account JSON. Voices: en-IN, hi-IN, te-IN, kn-IN.
  gtts         : gTTS — free, no key, uses Google Translate's speech endpoint
                 (unofficial, needs internet). Supports en, hi, te, kn.
  auto         : google_cloud if configured, otherwise gtts.
"""

from __future__ import annotations

import io
import logging
import os
import re

from modules.language_handler import LANGUAGES

log = logging.getLogger(__name__)

MAX_TTS_CHARS = 2500


class TTSError(Exception):
    pass


def clean_for_speech(text: str) -> str:
    """Remove citations, markdown and symbols that sound bad when read aloud."""
    text = re.sub(r"\s*\[S\d+\]", "", text)
    text = re.sub(r"[*_#`>|]+", "", text)
    text = re.sub(r"^\s*[-•]\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{2,}", "\n", text).strip()
    if len(text) > MAX_TTS_CHARS:
        cut = text[:MAX_TTS_CHARS]
        text = cut[: max(cut.rfind("."), cut.rfind("।"), MAX_TTS_CHARS // 2) + 1]
    return text


def google_cloud_available() -> bool:
    if not os.getenv("GOOGLE_APPLICATION_CREDENTIALS"):
        return False
    try:
        from google.cloud import texttospeech  # noqa: F401
        return True
    except ImportError:
        return False


def _google_cloud(text: str, lang: str) -> bytes:
    from google.cloud import texttospeech

    client = texttospeech.TextToSpeechClient()
    resp = client.synthesize_speech(
        input=texttospeech.SynthesisInput(text=text),
        voice=texttospeech.VoiceSelectionParams(language_code=LANGUAGES[lang]["gcloud"]),
        audio_config=texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3, speaking_rate=0.9),
    )
    return resp.audio_content


def _gtts(text: str, lang: str) -> bytes:
    try:
        from gtts import gTTS
    except ImportError as exc:
        raise TTSError("gTTS is not installed (pip install gTTS).") from exc
    buf = io.BytesIO()
    tld = "co.in" if lang == "en" else "com"
    gTTS(text=text, lang=LANGUAGES[lang]["gtts"], tld=tld, slow=False).write_to_fp(buf)
    return buf.getvalue()


def backend_name(backend: str = "auto") -> str:
    if backend == "auto":
        return "google_cloud" if google_cloud_available() else "gtts"
    return backend


def synthesize(text: str, lang: str, backend: str = "auto") -> tuple[bytes, str]:
    """Return (audio_bytes, mime_type). Raises TTSError with a friendly message."""
    if lang not in LANGUAGES:
        raise TTSError(f"Voice output is not available for language '{lang}'.")
    speech = clean_for_speech(text)
    if not speech:
        raise TTSError("There is no text to read aloud.")
    chosen = backend_name(backend)
    try:
        if chosen == "google_cloud":
            try:
                return _google_cloud(speech, lang), "audio/mp3"
            except Exception as exc:          # fall back rather than fail the demo
                log.warning("Google Cloud TTS failed (%s); falling back to gTTS", exc)
        return _gtts(speech, lang), "audio/mp3"
    except TTSError:
        raise
    except Exception as exc:
        raise TTSError(f"Voice service is not reachable right now ({type(exc).__name__}). "
                       "Check your internet connection; you can still read the answer.") from exc
