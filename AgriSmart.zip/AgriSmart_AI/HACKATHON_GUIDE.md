# AgriSmart AI — Hackathon Guide

## A. Before you go on stage (checklist)
- [ ] `python ingest.py` already run (vector_db/ exists), so you don't wait during the demo.
- [ ] `python tests/test_live.py` run at least once, with no CHECK on the questions you will demo.
- [ ] `.env` has a working `GOOGLE_API_KEY`; the sidebar shows "Gemini connected".
- [ ] Sidebar → Speech recognition = **Gemini** (best for Telugu/Kannada).
- [ ] The browser has microphone permission for `localhost:8501` (test one recording).
- [ ] Laptop volume up; internet working (Gemini, gTTS). Hotspot as backup.
- [ ] Backup plan: if the internet fails, type questions and show sources; describe voice.

## B. 5-minute demonstration script

| Time | What you do | What you say |
|---|---|---|
| 0:00–0:30 | Title screen / app header | "Farmers need trusted advice in their own language. Generic chatbots can invent pesticide doses. AgriSmart AI answers only from official agricultural manuals and shows the page it used." |
| 0:30–1:15 | Show `data/` with the 4 PDFs; run `python ingest.py --check` (or show the earlier ingest output) | "We index four real documents: TNAU's Crop Production Guide, UAS Bangalore's Package of Practices in Kannada, FAO's organic agriculture manual, and an agroecology handbook — about 880 pages, 2,800 chunks, stored as 384-dimension vectors in ChromaDB. The Kannada book used an old font that comes out as gibberish, so we wrote a converter to real Unicode Kannada." |
| 1:15–2:00 | Click the 💧 card question *"What are the advantages of drip irrigation?"*, then open 📚 Sources | "The question is embedded, the most similar passages are retrieved, and Gemini must answer only from them and cite them. Here are the file names and PDF page numbers, and the exact passages used." |
| 2:00–3:00 | Switch the language to **తెలుగు**, press the mic, say *"బిందు సేద్యం వల్ల లాభాలు ఏమిటి?"*, show the recognised text, send, press 🔊 వినండి | "A farmer who can't read English just speaks. Speech-to-text, retrieval from English documents through query translation, an answer in Telugu, and it's read aloud." |
| 3:00–3:45 | Switch to **ಕನ್ನಡ**, ask *"ಭತ್ತಕ್ಕೆ ನೀರು ನಿರ್ವಹಣೆ ಹೇಗೆ ಮಾಡಬೇಕು?"* | "This answer comes from the Kannada UAS Bangalore book itself — see the page numbers." |
| 3:45–4:15 | Ask *"What is today's market price of tomatoes?"* | "When the documents don't have the answer, it says so and suggests the Krishi Vigyan Kendra instead of guessing." |
| 4:15–5:00 | Show the architecture diagram (README §3) | "PDF → extraction → chunking → multilingual embeddings → ChromaDB → retrieval → Gemini with a grounding prompt → cited answer → speech. Next steps: Bhashini voice, farmer location, more state manuals." |

## C. Why RAG instead of training a model from scratch
1. **Data**: we have ~880 pages of text. Training a language model from scratch needs
   billions of words and GPU clusters; fine-tuning still needs thousands of labelled Q&A pairs
   that we don't have.
2. **Trust and traceability**: RAG shows the exact document and page behind each answer. A
   trained model mixes knowledge from everywhere and can't cite where a dose came from.
3. **Hallucination control**: the model is told to use only retrieved passages and to answer
   NOT_FOUND otherwise. If retrieval finds nothing, Gemini isn't called at all.
4. **Easy updates**: when UAS publishes the 2026 Package of Practices, we drop the PDF in
   `data/` and re-run ingestion in minutes. No retraining.
5. **Cost and time**: it runs on a laptop with a free API key, within a hackathon timeline.
6. **Multilingual for free**: a strong existing LLM already writes Telugu, Kannada and Hindi;
   we only supply the trusted facts.

## D. Honest explanation of sources and data collection
- Four PDFs were downloaded manually from public websites of TNAU, UAS Bangalore, FAO and
  Focus on the Global South. Nothing was scraped, generated or taken from Kaggle.
- The fourth PDF was first believed to be an FAO sustainable-agriculture manual. On checking
  its title page and metadata (`Agriculture Science.cdr`, a design-file name), we found it is
  the *Handbook on Agroecology* by Focus on the Global South (2014), and corrected all labels.
- The only processing is text extraction, cleaning, and converting the legacy-font Kannada
  book to Unicode. Text is chunked page by page so each answer can be traced to a PDF page.
- Coverage of the five PS-14 topics was measured on the extracted text (README §5), not assumed.

## E. 15 likely judge questions with answers

1. **How is this different from just asking ChatGPT/Gemini?**
   Gemini never answers alone. Every question first retrieves passages from our four manuals;
   Gemini receives only those passages with rules to cite them and not invent numbers. If
   nothing relevant is retrieved, Gemini isn't called and the app says the knowledge base
   doesn't have the answer.

2. **What embedding model do you use and why?**
   `paraphrase-multilingual-MiniLM-L12-v2`: 384-dimensional, fast on CPU, and trained for 50+
   languages so English and Hindi questions match English text. It doesn't cover Telugu or
   Kannada, so we also search with a Gemini-made English translation of the question.

3. **How do you chunk documents?**
   About 800 characters with 150 overlap, split recursively at paragraph, line and sentence
   boundaries, never across pages, so every chunk has an exact PDF page. Table-of-contents
   and title-only chunks are dropped because they match many queries but contain no advice.

4. **What similarity metric and threshold?**
   Cosine similarity on normalised vectors (ChromaDB cosine distance, converted with
   1 − distance). Main threshold 0.25; between 0.15 and 0.25 the top 3 passages go to Gemini as
   weak matches and Gemini decides; below 0.15 we answer "not found" without calling the LLM.
   We calibrate with `tests/test_live.py`, which compares scores of answerable and
   unanswerable questions.

5. **How do you stop hallucinated pesticide doses?**
   The system prompt forbids any quantity that isn't in a cited passage, requires exact units
   and the crop/region, separates "from the documents" from "general guidance", and asks the
   farmer to confirm doses with the KVK. Temperature is 0.2.

6. **How do you handle the Kannada PDF?**
   It is typed in the legacy Nudi font, which stores Kannada as Latin-1 codes. We detect Nudi
   font spans with PyMuPDF and convert them with our own glyph-to-Unicode converter (consonant
   bases, vowel signs, subscript consonants, reph). The result is about 76% Kannada script with
   under 0.1% leftover junk.

7. **Why ChromaDB?**
   It's embedded (no server), persists to a local folder, supports cosine search and metadata,
   and is enough for about 3,000 chunks. A manifest of file hashes means we only re-embed
   when a PDF changes.

8. **How does voice work?**
   The browser records WAV through Streamlit's `st.audio_input`. We transcribe with Whisper
   locally or Gemini in the cloud, show the text for correction, run the same RAG pipeline,
   and speak the answer with gTTS or Google Cloud TTS in the selected language.

9. **Does it work offline?**
   Ingestion and retrieval work offline after the model download. Gemini, gTTS and Gemini STT
   need internet; Whisper works offline. A fully offline version would need a local LLM.

10. **How accurate is it?**
    We test 18 questions across five topics, four languages and two unanswerable cases with
    `tests/test_live.py`, checking source documents, answer language and correct "not found"
    behaviour. *(Quote your actual PASS count here.)* We don't claim agronomic accuracy beyond
    what the source manuals say.

11. **The TNAU guide is for Tamil Nadu. Is the advice valid elsewhere?**
    Not necessarily. The prompt makes Gemini state that recommendations depend on location,
    season, soil and water, and say when a source is region-specific. Adding a farmer-location
    filter is our next step.

12. **How do you add new knowledge?**
    Copy a PDF into `data/` and run `python ingest.py`. New or changed files are detected by
    SHA-1 fingerprint and indexed automatically; `sources.json` optionally sets the display name.

13. **What happens if the API key is wrong or the model is retired?**
    The app shows a clear message (invalid key, quota, no internet). If a Gemini model isn't
    available for the key, it automatically falls back to the next model in a list.

14. **How do you handle privacy?**
    There are no accounts and no database of questions; chat history lives only in the running
    app's memory on the laptop and disappears when the session ends. Questions and audio are sent to Gemini/Google TTS only to produce the
    answer. API keys stay in `.env`, outside version control.

15. **What would you build next?**
    Bhashini integration for Indian-language voice, an embedding model covering Telugu and
    Kannada, farmer profiles (district, soil, season), more state manuals, and WhatsApp/IVR
    access for farmers without smartphones.
