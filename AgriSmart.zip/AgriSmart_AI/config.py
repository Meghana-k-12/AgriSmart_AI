"""Central configuration. Values can be overridden in the .env file."""

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


def _float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


# --- Paths -----------------------------------------------------------------
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data"))
VECTOR_DB_DIR = Path(os.getenv("VECTOR_DB_DIR", BASE_DIR / "vector_db"))
SOURCES_FILE = DATA_DIR / "sources.json"          # optional display names
MANIFEST_FILE = VECTOR_DB_DIR / "manifest.json"   # what is currently indexed

# --- Chunking --------------------------------------------------------------
CHUNK_SIZE = _int("CHUNK_SIZE", 800)
CHUNK_OVERLAP = _int("CHUNK_OVERLAP", 150)
MIN_PAGE_CHARS = _int("MIN_PAGE_CHARS", 40)       # skip near-empty pages

# --- Embeddings / vector store --------------------------------------------
EMBEDDING_MODEL = os.getenv(
    "EMBEDDING_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
)
# The model's default limit is 128 tokens (~ 500 English characters); 800-char
# chunks would be cut off. The underlying XLM-R network accepts 512 positions.
EMBEDDING_MAX_SEQ_LENGTH = _int("EMBEDDING_MAX_SEQ_LENGTH", 256)
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "agrismart_docs")

# --- Retrieval -------------------------------------------------------------
TOP_K = _int("TOP_K", 6)
# Cosine similarity (-1..1). ChromaDB returns cosine DISTANCE; we use 1 - distance.
MIN_SIMILARITY = _float("MIN_SIMILARITY", 0.25)   # normal cut-off
SIMILARITY_FLOOR = _float("SIMILARITY_FLOOR", 0.15)  # weak matches still checked by Gemini
TRANSLATE_QUERY = os.getenv("TRANSLATE_QUERY", "true").lower() == "true"

# --- LLM -------------------------------------------------------------------
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash")
LLM_TEMPERATURE = _float("LLM_TEMPERATURE", 0.2)

# --- Voice -----------------------------------------------------------------
STT_BACKEND = os.getenv("STT_BACKEND", "whisper")     # whisper | gemini
WHISPER_MODEL = os.getenv("WHISPER_MODEL", "small")   # tiny/base/small/medium
TTS_BACKEND = os.getenv("TTS_BACKEND", "auto")        # auto | gtts | google_cloud
