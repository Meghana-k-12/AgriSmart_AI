"""
Offline tests — no API key, no model download, no ChromaDB needed.

They check the parts that do not depend on external services:
Kannada (Nudi) conversion, chunking, manifest change detection, language
detection, and the RAG logic (merging, thresholds, citations, NOT_FOUND)
using a TF-IDF stand-in embedder, an in-memory store and a fake LLM.

    python -m unittest tests.test_offline -v
"""

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from modules.kannada_nudi import nudi_to_unicode                      # noqa: E402
from modules.language_handler import detect_language, t              # noqa: E402
from modules.rag_pipeline import RAGPipeline, cited_indices          # noqa: E402
from modules.text_processor import Page, chunk_pages, split_text     # noqa: E402
from modules.vector_store import build_manifest, manifest_changes    # noqa: E402


# ---------------------------------------------------------------- stand-ins
class MemoryStore:
    """Same interface as VectorStore, cosine similarity on normalised vectors."""

    def __init__(self):
        self.items = []

    def count(self):
        return len(self.items)

    def reset(self):
        self.items = []

    def add(self, ids, texts, embeddings, metadatas, batch_size=1000):
        self.items += list(zip(ids, texts, embeddings, metadatas))

    def query(self, embedding, k=6):
        scored = [(sum(a * b for a, b in zip(embedding, e)), i, tx, m)
                  for i, tx, e, m in self.items]
        scored.sort(reverse=True)
        return [{"id": i, "text": tx, "metadata": m, "similarity": s}
                for s, i, tx, m in scored[:k]]


class TfidfEmbedder:
    def fit(self, texts):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.v = TfidfVectorizer(stop_words="english", sublinear_tf=True).fit(texts)
        return self

    def embed_documents(self, texts, **_):
        return self.v.transform(texts).toarray().tolist()

    def embed_query(self, text):
        return self.v.transform([text]).toarray()[0].tolist()


class BowEmbedder:
    """Pure-Python bag-of-words embedder (no numpy/sklearn) so tests run anywhere."""
    STOP = {"the", "a", "of", "and", "is", "what", "are", "to", "in", "how", "for"}

    def fit(self, texts):
        words = sorted({w for tx in texts for w in self._words(tx)})
        self.index = {w: i for i, w in enumerate(words)}
        return self

    def _words(self, text):
        import re
        return [w for w in re.findall(r"\w+", text.lower()) if w not in self.STOP]

    def _vec(self, text):
        v = [0.0] * len(self.index)
        for w in self._words(text):
            if w in self.index:
                v[self.index[w]] += 1.0
        n = sum(x * x for x in v) ** 0.5 or 1.0
        return [x / n for x in v]

    def embed_documents(self, texts, **_):
        return [self._vec(tx) for tx in texts]

    def embed_query(self, text):
        return self._vec(text)


class FakeLLM:
    def __init__(self, reply="**Answer:** Drip saves water [S1].", translation=None):
        self.reply, self.translation, self.prompts = reply, translation, []

    def translate_to_english(self, text):
        return self.translation or text

    def generate(self, prompt, system=None, temperature=None):
        self.prompts.append(prompt)
        return self.reply


def _page(text, page=1, src="a.pdf"):
    return Page(text=text, source=src, title="Doc " + src, page=page, language="en")


# ---------------------------------------------------------------- tests
class TestKannada(unittest.TestCase):
    def test_words(self):
        cases = {"ªÀiÁ»w": "ಮಾಹಿತಿ", "PÀ£ÁðlPÀ": "ಕರ್ನಾಟಕ", "¤ÃgÀÄ": "ನೀರು",
                 "«eÁÕ£À": "ವಿಜ್ಞಾನ", "UÉÆ§âgÀ": "ಗೊಬ್ಬರ", "¥ÀæzÉÃ±À": "ಪ್ರದೇಶ",
                 "PÀÈ¶": "ಕೃಷಿ", "ªÀÄzsÀå": "ಮಧ್ಯ", "AiÉÆÃd£É": "ಯೋಜನೆ",
                 "mÁåçPÀÖgï": "ಟ್ರ್ಯಾಕ್ಟರ್", "§¼ÀPÉ": "ಬಳಕೆ"}
        for nudi, expected in cases.items():
            self.assertEqual(nudi_to_unicode(nudi), expected, nudi)

    def test_numbers_pass_through(self):
        self.assertEqual(nudi_to_unicode("±ÉÃ.50 E.¹"), "ಶೇ.50 ಇ.ಸಿ")


class TestChunking(unittest.TestCase):
    def test_sizes_and_overlap(self):
        text = " ".join(f"Sentence number {i} about soil and water." for i in range(200))
        chunks = split_text(text, 800, 150)
        self.assertTrue(all(len(c) <= 800 for c in chunks))
        self.assertGreater(len(chunks), 5)
        self.assertIn(chunks[0][-60:].split()[-1], chunks[1])   # overlap carried over

    def test_metadata_preserved(self):
        chunks = chunk_pages([_page("Crop rotation improves soil health. " * 40, page=7)])
        self.assertTrue(all(c.metadata["page"] == 7 for c in chunks))
        self.assertEqual(len({c.id for c in chunks}), len(chunks))


class TestManifest(unittest.TestCase):
    def test_change_detection(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "x.pdf"
            p.write_bytes(b"one")
            m1 = build_manifest([p], {"chunk_size": 800})
            self.assertEqual(manifest_changes(m1, m1), [])
            p.write_bytes(b"two")
            self.assertTrue(manifest_changes(m1, build_manifest([p], {"chunk_size": 800})))
            self.assertTrue(manifest_changes(m1, build_manifest([p], {"chunk_size": 500})))
            self.assertEqual(manifest_changes(None, m1), ["no existing index"])


class TestLanguage(unittest.TestCase):
    def test_detect(self):
        self.assertEqual(detect_language("ఎర్ర నేలకు ఏ పంటలు?"), "te")
        self.assertEqual(detect_language("ಹನಿ ನೀರಾವರಿ"), "kn")
        self.assertEqual(detect_language("ड्रिप सिंचाई"), "hi")
        self.assertEqual(detect_language("drip irrigation"), "en")
        self.assertIsNone(detect_language("123 ?"))

    def test_ui_strings(self):
        for lang in ("en", "te", "kn", "hi"):
            self.assertTrue(t(lang, "not_found"))


class TestRAG(unittest.TestCase):
    def setUp(self):
        pages = [_page("Drip irrigation saves water and reduces weeds.", 3, "a.pdf"),
                 _page("Crop rotation breaks pest cycles and improves soil.", 9, "b.pdf"),
                 _page("Organic manure adds humus and improves soil fertility.", 4, "b.pdf")]
        chunks = chunk_pages(pages, min_chunk_chars=10)
        self.emb = BowEmbedder().fit([c.text for c in chunks])
        self.store = MemoryStore()
        self.store.add([c.id for c in chunks], [c.text for c in chunks],
                       self.emb.embed_documents([c.text for c in chunks]),
                       [c.metadata for c in chunks])

    def test_grounded_answer_with_sources(self):
        llm = FakeLLM()
        rag = RAGPipeline(self.emb, self.store, llm, top_k=2, min_similarity=0.05)
        ans = rag.answer("advantages of drip irrigation", "en")
        self.assertEqual(ans.status, "ok")
        self.assertEqual(ans.sources[0]["source"], "a.pdf")
        self.assertEqual(ans.sources[0]["pages"], [3])
        self.assertIn("[S1]", llm.prompts[0])
        self.assertIn("PDF page 3", llm.prompts[0])

    def test_empty_question(self):
        rag = RAGPipeline(self.emb, self.store, FakeLLM())
        self.assertEqual(rag.answer("   ", "te").status, "empty")

    def test_no_relevant_chunks(self):
        rag = RAGPipeline(self.emb, self.store, FakeLLM(), min_similarity=0.3)
        ans = rag.answer("price of tractors in Delhi", "kn")
        self.assertEqual(ans.status, "not_found")
        self.assertEqual(ans.answer, t("kn", "not_found"))

    def test_llm_not_found_marker(self):
        rag = RAGPipeline(self.emb, self.store, FakeLLM("NOT_FOUND\nNot in documents."),
                          min_similarity=0.05)
        ans = rag.answer("drip irrigation subsidy amount", "en")
        self.assertEqual(ans.status, "not_found")
        self.assertEqual(ans.sources, [])

    def test_translation_added_to_search(self):
        llm = FakeLLM(translation="benefits of organic manure")
        rag = RAGPipeline(self.emb, self.store, llm, top_k=2, min_similarity=0.05)
        ans = rag.answer("సేంద్రియ ఎరువు ప్రాముఖ్యత ఏమిటి?", "te")
        self.assertEqual(ans.search_queries[1], "benefits of organic manure")
        self.assertEqual(ans.status, "ok")
        self.assertIn("Telugu", llm.prompts[0])

    def test_retrieval_only_without_llm(self):
        rag = RAGPipeline(self.emb, self.store, None, min_similarity=0.05)
        ans = rag.answer("crop rotation", "en")
        self.assertEqual(ans.status, "retrieval_only")
        self.assertTrue(ans.hits)

    def test_gemini_receives_retrieved_context(self):
        llm = FakeLLM()
        rag = RAGPipeline(self.emb, self.store, llm, top_k=2, min_similarity=0.05)
        rag.answer("What is crop rotation?", "en")
        prompt = llm.prompts[0]
        self.assertIn("Crop rotation breaks pest cycles", prompt)   # chunk text itself
        self.assertIn("file b.pdf, PDF page 9", prompt)              # filename + page
        self.assertIn("What is crop rotation?", prompt)

    def test_llm_not_called_without_evidence(self):
        llm = FakeLLM()
        rag = RAGPipeline(self.emb, self.store, llm, min_similarity=0.9, similarity_floor=0.9)
        ans = rag.answer("price of tractors in Delhi", "en")
        self.assertEqual(ans.status, "not_found")
        self.assertEqual(llm.prompts, [])

    def test_weak_match_fallback_goes_to_gemini(self):
        llm = FakeLLM("**Answer:** Manure adds humus [S1].")
        # threshold too strict, but floor lets the best matches through to Gemini
        rag = RAGPipeline(self.emb, self.store, llm, min_similarity=0.95, similarity_floor=0.1)
        ans = rag.answer("importance of organic manure", "en")
        self.assertEqual(ans.status, "ok")
        self.assertTrue(all(h.get("weak_match") for h in ans.hits))
        self.assertLessEqual(len(ans.hits), 3)

    def test_language_in_prompt(self):
        for lang, name in [("te", "Telugu"), ("kn", "Kannada"), ("hi", "Hindi")]:
            llm = FakeLLM()
            RAGPipeline(self.emb, self.store, llm, min_similarity=0.05).answer(
                "drip irrigation", lang)
            self.assertIn(f"Write the whole answer in {name}", llm.prompts[0])

    def test_citation_parse(self):
        self.assertEqual(cited_indices("a [S2] b [S1][S2] c [S9]", 3), [1, 2])


try:
    import numpy  # noqa: F401
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


@unittest.skipUnless(HAS_NUMPY, "numpy not installed")
class TestVoiceHelpers(unittest.TestCase):
    def _wav(self, rate=44100, seconds=1.0, amp=8000, channels=2):
        import io, math, struct, wave
        buf = io.BytesIO()
        with wave.open(buf, "wb") as w:
            w.setnchannels(channels); w.setsampwidth(2); w.setframerate(rate)
            frames = b"".join(struct.pack("<h", int(amp * math.sin(i / 20))) * channels
                              for i in range(int(rate * seconds)))
            w.writeframes(frames)
        return buf.getvalue()

    def test_wav_decode_resample(self):
        from modules.speech_to_text import wav_to_float32_16k
        audio = wav_to_float32_16k(self._wav())
        self.assertAlmostEqual(len(audio), 16000, delta=2)
        self.assertLessEqual(float(abs(audio).max()), 1.0)

    def test_silence_rejected(self):
        from modules.speech_to_text import STTError, transcribe_gemini
        with self.assertRaises(STTError):
            transcribe_gemini(self._wav(amp=0), "te", llm=object())

    def test_bad_audio(self):
        from modules.speech_to_text import STTError, wav_to_float32_16k
        with self.assertRaises(STTError):
            wav_to_float32_16k(b"not a wav")

    def test_clean_for_speech(self):
        from modules.text_to_speech import clean_for_speech
        out = clean_for_speech("**Answer:** Use mulch [S1].\n- Drip saves water [S2]")
        self.assertEqual(out, "Answer: Use mulch.\nDrip saves water")


class TestTitlesAndGemini(unittest.TestCase):
    def test_bad_metadata_titles_rejected(self):
        from modules.document_loader import usable_meta_title
        self.assertIsNone(usable_meta_title("Agriculture Science.cdr"))
        self.assertIsNone(usable_meta_title("Microsoft Word - draft.docx"))
        self.assertEqual(usable_meta_title("Training manual for ORGANIC AGRICULTURE"),
                         "Training manual for ORGANIC AGRICULTURE")

    def _client(self, behaviour):
        from modules.llm import GeminiClient

        class Resp:
            text = "ok"

        class Models:
            calls = []

            def generate_content(self, model, contents, config):
                Models.calls.append(model)
                err = behaviour.get(model)
                if err:
                    raise err
                return Resp()

        class Types:
            class GenerateContentConfig:
                def __init__(self, **k):
                    pass

        c = GeminiClient.__new__(GeminiClient)
        c.client = type("C", (), {"models": Models()})()
        c._types = Types
        c.models = ["gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"]
        c.model, c.temperature = c.models[0], 0.2
        return c, Models.calls

    def test_model_fallback(self):
        class NotFound(Exception):
            code = 404
        c, calls = self._client({"gemini-3.8-flash": NotFound("model not found")})
        self.assertEqual(c.generate("hi"), "ok")
        self.assertEqual(c.model, "gemini-3.5-flash-lite")

    def test_bad_key_not_retried(self):
        from modules.llm import LLMError

        class Bad(Exception):
            code = 400
        c, calls = self._client({"gemini-3.8-flash": Bad("API key not valid")})
        with self.assertRaises(LLMError) as cm:
            c.generate("hi")
        self.assertEqual(cm.exception.kind, "auth")
        self.assertEqual(calls, ["gemini-3.8-flash"])


if __name__ == "__main__":
    unittest.main()
