"""
Live end-to-end test against the REAL embedding model, ChromaDB and Gemini.
Run after `python ingest.py`.

    python tests/test_live.py --retrieval-only   # no API key needed
    python tests/test_live.py                    # full answers (uses Gemini)
    python tests/test_live.py --voice            # also test gTTS in 4 languages

Output: for each question the top retrieved documents/pages with similarity,
and (if Gemini is enabled) the status and the first lines of the answer.
A report is saved to tests/live_report.md.
"""

import argparse
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import config  # noqa: E402
from modules.embeddings import Embedder  # noqa: E402
from modules.language_handler import detect_language  # noqa: E402
from modules.rag_pipeline import RAGPipeline  # noqa: E402
from modules.vector_store import VectorStore  # noqa: E402

QUESTIONS = [
    # (domain, language, question, expectation)
    ("Crop selection", "en", "Which crops are suitable for red soil?", "answer"),
    ("Crop selection", "en", "What factors should I consider before selecting a crop?", "answer"),
    ("Irrigation", "en", "What are the advantages of drip irrigation?", "answer, multiple docs"),
    ("Irrigation", "en", "How can farmers reduce water wastage?", "answer"),
    ("Soil", "en", "How can I improve soil fertility?", "answer, multiple docs"),
    ("Soil", "en", "What is the importance of organic manure?", "answer"),
    ("Pests", "en", "What are sustainable ways to prevent crop pests?", "answer"),
    ("Pests", "en", "What integrated pest management practices are recommended?", "answer"),
    ("Sustainable", "en", "What is crop rotation?", "answer, multiple docs"),
    ("Sustainable", "en", "What are the benefits of organic farming?", "answer"),
    ("Telugu", "te", "బిందు సేద్యం వల్ల లాభాలు ఏమిటి?", "answer in Telugu"),
    ("Telugu", "te", "సేంద్రియ ఎరువు ప్రాముఖ్యత ఏమిటి?", "answer in Telugu"),
    ("Kannada", "kn", "ಭತ್ತಕ್ಕೆ ನೀರು ನಿರ್ವಹಣೆ ಹೇಗೆ ಮಾಡಬೇಕು?", "should hit UAS Bangalore (Kannada)"),
    ("Kannada", "kn", "ಸಾವಯವ ಕೃಷಿಯ ಪ್ರಯೋಜನಗಳೇನು?", "answer in Kannada"),
    ("Hindi", "hi", "फसल चक्र क्या है?", "answer in Hindi"),
    ("Hindi", "hi", "मिट्टी की उर्वरता कैसे बढ़ाएँ?", "answer in Hindi"),
    ("Missing info", "en", "What is today's market price of tomatoes in Bangalore?", "NOT_FOUND"),
    ("Missing info", "en", "How do I repair a tractor gearbox?", "NOT_FOUND"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--retrieval-only", action="store_true")
    ap.add_argument("--voice", action="store_true")
    args = ap.parse_args()

    store = VectorStore(config.VECTOR_DB_DIR, config.COLLECTION_NAME)
    if store.count() == 0:
        print("Vector DB is empty — run `python ingest.py` first.")
        return 1
    print(f"Vector DB: {store.count()} chunks")

    llm = None
    if not args.retrieval_only:
        from modules.llm import GeminiClient, LLMError
        try:
            llm = GeminiClient(config.GOOGLE_API_KEY, config.GEMINI_MODEL)
        except LLMError as exc:
            print(f"Gemini unavailable ({exc}); running retrieval only.")

    emb = Embedder(config.EMBEDDING_MODEL, config.EMBEDDING_MAX_SEQ_LENGTH)
    rag = RAGPipeline(emb, store, llm, top_k=config.TOP_K,
                      min_similarity=config.MIN_SIMILARITY,
                       similarity_floor=config.SIMILARITY_FLOOR,
                      translate_query=config.TRANSLATE_QUERY)

    lines = ["# AgriSmart AI live test report", ""]
    best_relevant, best_missing, results = [], [], []
    for domain, lang, q, expect in QUESTIONS:
        t0 = time.time()
        raw = rag.store.query(rag.embedder.embed_query(q), k=1)   # raw best similarity
        best = raw[0]["similarity"] if raw else 0.0
        if llm is None:
            hits, queries = rag.retrieve(q, lang)
            status, answer = ("hits" if hits else "not_found"), ""
        else:
            res = rag.answer(q, lang)
            hits, queries, status, answer = res.hits, res.search_queries, res.status, res.answer
        dt = time.time() - t0
        docs = {h["metadata"]["source"] for h in hits}

        checks = []
        if expect == "NOT_FOUND":
            best_missing.append(best)
            checks.append(status == "not_found")
        else:
            best_relevant.append(best)
            checks.append(status in ("ok", "hits"))
            if "multiple docs" in expect:
                checks.append(len(docs) >= 2)
            if "UAS Bangalore" in expect:
                checks.append(any("POP-Final" in d for d in docs))
            if answer and lang != "en":
                checks.append(detect_language(answer) == lang)
        verdict = "PASS" if all(checks) else "CHECK"
        results.append(verdict)

        print(f"\n[{verdict}] [{domain}/{lang}] {q}\n  expected: {expect} | got: {status} | "
              f"docs: {len(docs)} | best raw similarity {best:.3f} | {dt:.1f}s")
        lines += [f"## [{verdict}] [{domain}/{lang}] {q}",
                  f"Expected: {expect} — got **{status}**, {len(docs)} document(s), "
                  f"best raw similarity {best:.3f} ({dt:.1f}s)",
                  f"Search queries: {queries}", ""]
        for h in hits[:4]:
            m = h["metadata"]
            weak = " (weak match)" if h.get("weak_match") else ""
            row = f"  {h['similarity']:.3f}  {m['title'][:45]}  [{m['source']} p.{m['page']}]{weak}"
            print(row)
            lines.append("- " + row.strip())
        if answer:
            preview = answer.strip().replace("\n", " ")[:300]
            print("  answer:", preview)
            lines += ["", "> " + answer.strip().replace("\n", "\n> "), ""]

    # ---- threshold calibration from real scores (original-language query only)
    summary = [f"\nRESULT: {results.count('PASS')}/{len(results)} PASS",
               f"Similarity metric: cosine similarity (1 - ChromaDB cosine distance)",
               f"Current MIN_SIMILARITY={config.MIN_SIMILARITY}, "
               f"SIMILARITY_FLOOR={config.SIMILARITY_FLOOR}"]
    if best_relevant and best_missing:
        lo, hi = min(best_relevant), max(best_missing)
        summary.append(f"Relevant questions: best similarity min {lo:.3f} / "
                       f"median {sorted(best_relevant)[len(best_relevant)//2]:.3f}")
        summary.append(f"Missing-info questions: best similarity max {hi:.3f}")
        if lo > hi:
            summary.append(f"Suggested MIN_SIMILARITY ≈ {(lo + hi) / 2:.2f} (midpoint)")
        else:
            summary.append("Scores overlap: keep the threshold moderate and rely on Gemini's "
                           "NOT_FOUND rule (weak-match fallback is enabled).")
    for line in summary:
        print(line)
    lines += ["## Summary", ""] + summary

    if args.voice:
        from modules.text_to_speech import synthesize
        print("\nVoice output test:")
        for lang, text in [("en", "Drip irrigation saves water."),
                           ("te", "బిందు సేద్యం నీటిని ఆదా చేస్తుంది."),
                           ("kn", "ಹನಿ ನೀರಾವರಿ ನೀರನ್ನು ಉಳಿಸುತ್ತದೆ."),
                           ("hi", "ड्रिप सिंचाई पानी बचाती है।")]:
            try:
                audio, _ = synthesize(text, lang, config.TTS_BACKEND)
                out = ROOT / "tests" / f"tts_{lang}.mp3"
                out.write_bytes(audio)
                print(f"  {lang}: OK ({len(audio)} bytes) -> {out.name}")
            except Exception as exc:
                print(f"  {lang}: FAILED {exc}")

    (ROOT / "tests" / "live_report.md").write_text("\n".join(lines), encoding="utf-8")
    print("\nReport saved to tests/live_report.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
