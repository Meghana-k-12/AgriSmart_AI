# AgriSmart AI — Audit Report (25 Nov 2026)

Environment used for the audit: Linux, Python 3.13 and Python 3.11.18. **Package installs
were blocked**, so sentence-transformers, ChromaDB, google-genai, Whisper, gTTS and
Streamlit could not be installed or run. Everything below marked "executed" was actually run.

## A. Features already working (executed)
- PDF loading of all 4 PDFs from `data/` (auto-detected, no hard-coded names): 871/880 pages with text, 0 failures.
- Nudi → Unicode Kannada conversion of the UAS book (76% Kannada script, < 0.1% junk).
- Cleaning + TOC/title filtering + 800/150 chunking with file name, title, publisher, PDF page: 2797 chunks.
- Change detection: rebuild → "up to date" → adding a new PDF triggers a rebuild.
- RAG logic: retrieval merge, cosine threshold + weak-match fallback, Gemini receives the retrieved passage text with file name and page, citations → sources, NOT_FOUND, Gemini not called without evidence, answer-language instruction.
- Gemini model fallback and API-key error classification (with a fake client).
- App control flow, 10 scenarios, with a fake Streamlit: no crashes.

## B. Bugs found and fixed
1. **Default Gemini model `gemini-2.5-flash` may be unavailable to new API keys**: Google now limits 2.5 models to existing users. → Default changed to `gemini-3.8-flash`, with automatic fallback `gemini-3.5-flash-lite` → `gemini-2.5-flash`. Errors are now classified as "model unavailable" vs "bad key".
2. **Threshold could cause false "not found"**: a hard cut-off at 0.25 dropped everything. → Weak-match fallback: if nothing reaches 0.25 but matches ≥ 0.15 exist, the top 3 go to Gemini, which must answer NOT_FOUND if irrelevant; below 0.15, Gemini isn't called.
3. **Metadata titles like `Agriculture Science.cdr` could become document titles** for un-listed PDFs. → Design-file/placeholder titles are rejected; fallback is the file name.
4. **Citations lacked the file name and publisher.** → Prompt passages and the UI sources now show title, publisher, file name and PDF pages.
5. **pdfplumber `(cid:131)` glyph junk in TNAU text** (fallback extractor). → Removed during cleaning.
6. **Invisible raw characters in cleaning regexes** (soft hyphen, private-use range). They worked, but were fragile. → Rewritten as escapes.
7. **Answer language**: a question in another script overrode the selected language. → The selected language wins; detection is used only when the selector is English.
8. **Sidebar rebuild didn't refresh the chunk list; the per-document summary re-read ChromaDB on every click.** → Summary cached by chunk count and refreshed after a rebuild.
9. **No help when the browser blocks the microphone** (not detectable from Python). → Translated help text under the mic.
10. **`tests/test_live.py` had never been executed** and had no pass criteria. → Executed end to end; it now prints PASS/CHECK per question (language, multi-document, UAS retrieval, not-found) and a threshold calibration.
11. Offline tests needed numpy/sklearn. → Pure-Python stand-in embedder, so they run on a bare Python 3.11; 7 new tests added (25 total).

Not a bug: no `svgpip` exists anywhere in the project; all docs use `pip install -r requirements.txt`.

## C. Implemented but not yet tested (needs your laptop)
- Real MiniLM embeddings → ChromaDB store/reload → retrieval quality and real similarity scores.
- Gemini answers, query translation and Telugu/Kannada/Hindi answer quality.
- Whisper and Gemini speech-to-text on real recordings; gTTS playback in 4 languages.
- Live Streamlit page layout, microphone capture, autoplay.

## D. Requires API keys / external services
| Feature | Needs |
|---|---|
| Gemini answers, query translation, Gemini STT | `GOOGLE_API_KEY` from aistudio.google.com/apikey + internet |
| gTTS voice output | Internet (no key) |
| Google Cloud TTS (optional) | GCP project, Text-to-Speech API, service-account JSON, `pip install google-cloud-texttospeech` |
| Whisper STT | No key; ~460 MB model download for `small` on first use |
| Embedding model | One-time ~470 MB download from Hugging Face |
| Bhashini | Not implemented (needs ULCA registration/keys) |

## E. Test results (actual outputs)
```
python3 -m unittest tests.test_offline      → Ran 25 tests ... OK
python3.11 -m unittest tests.test_offline   → Ran 25 tests ... OK (skipped=4)   [numpy absent on 3.11]
python3.11 -m py_compile <every .py file>   → all OK
ingest() with stand-ins                     → RUN1 rebuilt 2797 | RUN2 up_to_date |
                                              RUN3 "Rebuilding because: new file: New_Sustainable_Agriculture_Manual.pdf"
app smoke test (fake Streamlit)             → 10/10 scenarios completed, no exception
tests/test_live.py (TF-IDF stand-in)        → ran without errors; Kannada rice-water question → UAS Bangalore pp. 30–31
```
Stand-in similarity scores are **not** representative of the real model and aren't used to
claim retrieval quality.

## F. Remaining limitations
See README §10: PDF (not printed) page numbers; region-specific sources; embedding model
lacks Telugu/Kannada (translation needed, so internet needed); Whisper Telugu/Kannada accuracy;
gTTS is unofficial; 256-token embedding window; advisory only.

## G. Commands to run on your laptop
See README §8 (install, `.env`, run order).

## H. Readiness
Code and documentation are ready. The demo is ready **once `tests/test_live.py` passes on
your laptop** with your API key. That run is the first time the real model, ChromaDB and
Gemini are exercised.
