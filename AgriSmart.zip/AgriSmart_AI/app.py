"""
AgriSmart AI — multilingual, voice-enabled agricultural RAG assistant.

    streamlit run app.py
"""

from __future__ import annotations

import hashlib
import logging

import streamlit as st

st.set_page_config(page_title="AgriSmart AI", page_icon="🌾", layout="wide",
                   initial_sidebar_state="collapsed")

import config  # noqa: E402
from modules.language_handler import (CATEGORIES, CATEGORY_ICONS, LANGUAGES,  # noqa: E402
                                      detect_language, suggestions, t)
from modules.rag_pipeline import RAGPipeline  # noqa: E402
from modules.speech_to_text import STTError, transcribe  # noqa: E402
from modules.text_to_speech import TTSError, backend_name, synthesize  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

# ---------------------------------------------------------------------------
# Styling
# ---------------------------------------------------------------------------
st.markdown("""
<style>
html, body, [class*="css"] { font-size: 18px; }
.block-container { padding-top: 1.2rem; max-width: 1200px; }
.agri-header {
  background: linear-gradient(120deg, #1b5e20 0%, #2e7d32 55%, #66bb6a 100%);
  color: #fff; border-radius: 18px; padding: 18px 24px; margin-bottom: 8px;
}
.agri-header h1 { color: #fff; margin: 0; font-size: 2.1rem; }
.agri-header p  { color: #e8f5e9; margin: 2px 0 0 0; font-size: 1.1rem; }
.agri-welcome {
  background: #f1f8e9; border-left: 6px solid #43a047; border-radius: 12px;
  padding: 12px 18px; font-size: 1.15rem; color: #1b5e20; margin: 6px 0 14px 0;
}
.agri-card {
  background: #ffffff; border: 2px solid #c8e6c9; border-radius: 16px;
  padding: 10px 6px; text-align: center; margin-bottom: 6px;
}
.agri-card .icon { font-size: 2.2rem; line-height: 1.1; }
.agri-card .title { font-weight: 700; color: #1b5e20; font-size: 1.05rem; }
.agri-disclaimer {
  background: #fffde7; border: 1px solid #fff59d; border-radius: 10px;
  padding: 10px 14px; font-size: 0.95rem; color: #5d4037; margin-top: 14px;
}
.agri-source { font-size: 0.95rem; color: #2e7d32; }
div.stButton > button, div.stFormSubmitButton > button {
  min-height: 3rem; font-size: 1.05rem; border-radius: 12px;
  border: 2px solid #a5d6a7;
}
div.stFormSubmitButton > button {
  background: #2e7d32; color: #fff; border-color: #2e7d32; font-weight: 700;
}
div.stFormSubmitButton > button:hover { background: #1b5e20; color: #fff; }
textarea { font-size: 1.1rem !important; }
</style>
""", unsafe_allow_html=True)


def wide_button(label: str, key: str, **kwargs) -> bool:
    """st.button stretched to its column (works across Streamlit versions)."""
    try:
        return st.button(label, key=key, width="stretch", **kwargs)
    except TypeError:
        return st.button(label, key=key, use_container_width=True, **kwargs)


def wide_submit(label: str) -> bool:
    try:
        return st.form_submit_button(label, width="stretch")
    except TypeError:
        return st.form_submit_button(label, use_container_width=True)


def play_audio(data: bytes, autoplay: bool = False) -> None:
    try:
        st.audio(data, format="audio/mp3", autoplay=autoplay)
    except TypeError:
        st.audio(data, format="audio/mp3")


# ---------------------------------------------------------------------------
# Cached resources
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def get_embedder():
    from modules.embeddings import Embedder
    emb = Embedder(config.EMBEDDING_MODEL, config.EMBEDDING_MAX_SEQ_LENGTH)
    _ = emb.model          # load now so the first question is fast
    return emb


@st.cache_resource(show_spinner=False)
def get_store():
    from modules.vector_store import VectorStore
    return VectorStore(config.VECTOR_DB_DIR, config.COLLECTION_NAME)


@st.cache_resource(show_spinner=False)
def get_llm():
    """Returns (client or None, error message or None)."""
    from modules.llm import GeminiClient, LLMError
    try:
        return GeminiClient(config.GOOGLE_API_KEY, config.GEMINI_MODEL,
                            config.LLM_TEMPERATURE), None
    except LLMError as exc:
        return None, str(exc)


def get_pipeline() -> RAGPipeline:
    llm, _ = get_llm()
    return RAGPipeline(get_embedder(), get_store(), llm, top_k=config.TOP_K,
                       min_similarity=config.MIN_SIMILARITY,
                       similarity_floor=config.SIMILARITY_FLOOR,
                       translate_query=config.TRANSLATE_QUERY)


# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
DEFAULTS = {"messages": [], "lang": "en", "question_input": "", "pending": None,
            "last_audio": None, "mic_round": 0, "stt_backend": config.STT_BACKEND,
            "auto_speak": False, "auto_send": False, "voice_error": None}
for k, v in DEFAULTS.items():
    st.session_state.setdefault(k, v)


def ask(question: str) -> None:
    st.session_state.pending = question


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------
lang_codes = list(LANGUAGES)
head_l, head_r = st.columns([4, 1.3])
with head_r:
    st.selectbox("🌐 " + t(st.session_state.lang, "language"), lang_codes, key="lang",
                 format_func=lambda c: LANGUAGES[c]["native"])
L = st.session_state.lang
with head_l:
    st.markdown(f"""<div class="agri-header"><h1>🌾 AgriSmart AI</h1>
                <p>{t(L, 'subtitle')}</p></div>""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Load knowledge base
# ---------------------------------------------------------------------------
try:
    with st.spinner("Loading the knowledge base…"):
        store = get_store()
except Exception as exc:
    st.error(f"Could not open the vector database ({exc}). "
             "Run `pip install -r requirements.txt` and `python ingest.py`.")
    st.stop()

llm_client, llm_error = get_llm()

# ---------------------------------------------------------------------------
# Sidebar: settings + status
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ Settings")
    st.toggle(t(L, "auto_speak"), key="auto_speak")
    st.toggle(t(L, "auto_send"), key="auto_send")
    st.radio("Speech recognition", ["whisper", "gemini"], key="stt_backend",
             format_func=lambda b: {"whisper": "Whisper (local)",
                                    "gemini": "Gemini (cloud, better for Telugu/Kannada)"}[b])
    st.caption(f"Voice output: {backend_name(config.TTS_BACKEND)}")

    st.header("📚 Knowledge base")
    st.metric("Indexed chunks", store.count())
    cached = st.session_state.get("doc_summary")
    if not cached or cached[0] != store.count():
        cached = (store.count(), store.documents_summary())
        st.session_state["doc_summary"] = cached
    for title, n in cached[1].items():
        st.caption(f"• {title}: {n}")
    if llm_client:
        st.success(f"Gemini connected ({config.GEMINI_MODEL})")
    else:
        st.warning(llm_error or "Gemini not configured")
    if st.button("🔄 Rebuild knowledge base"):
        st.session_state["force_rebuild"] = True
    st.markdown(f"<div class='agri-disclaimer'>{t(L, 'disclaimer')}</div>",
                unsafe_allow_html=True)


def build_index(force: bool) -> None:
    from ingest import ingest
    with st.status("Building knowledge base from data/ PDFs…", expanded=True) as status:
        try:
            summary = ingest(force=force, embedder=get_embedder(), store=store,
                             progress=lambda m: status.write(m))
            status.update(label=f"Knowledge base ready: {summary['chunks']} chunks",
                          state="complete")
        except Exception as exc:
            status.update(label=f"Indexing failed: {exc}", state="error")


if st.session_state.pop("force_rebuild", False):
    build_index(force=True)
    st.session_state.pop("doc_summary", None)
    st.button("✅ Done — refresh", on_click=lambda: None)

if store.count() == 0:
    st.warning(t(L, "kb_empty") + " Run `python ingest.py`, or press the button below "
               "(the first run downloads the embedding model and takes a few minutes).")
    if st.button("📥 Build knowledge base now"):
        build_index(force=False)
        st.rerun()
    st.stop()

# ---------------------------------------------------------------------------
# Welcome + topic cards
# ---------------------------------------------------------------------------
st.markdown(f"<div class='agri-welcome'>🙏 {t(L, 'welcome')}</div>", unsafe_allow_html=True)
st.subheader(t(L, "topics"))
cols = st.columns(len(CATEGORIES))
for col, cat in zip(cols, CATEGORIES):
    with col:
        st.markdown(f"<div class='agri-card'><div class='icon'>{CATEGORY_ICONS[cat]}</div>"
                    f"<div class='title'>{t(L, cat)}</div></div>", unsafe_allow_html=True)
        for j, q in enumerate(suggestions(L, cat)):
            wide_button(q, key=f"sugg_{cat}_{j}_{L}", on_click=ask, args=(q,))

st.divider()

# ---------------------------------------------------------------------------
# Chat history
# ---------------------------------------------------------------------------
def render_assistant(i: int, msg: dict) -> None:
    status = msg.get("status")
    if status == "not_found":
        st.warning(msg["content"])
    elif status == "error":
        st.error(msg["content"])
    elif status == "retrieval_only":
        st.info(msg["content"])
        for h in msg.get("hits", [])[:4]:
            m = h["metadata"]
            st.markdown(f"**📄 {m['title']} — PDF {t(L, 'page')} {m['page']}**")
            st.caption(h["text"][:600])
    else:
        st.markdown(msg["content"])

    if msg.get("sources"):
        with st.expander(f"📚 {t(L, 'sources')}", expanded=False):
            for s in msg["sources"]:
                pages = ", ".join(str(p) for p in s["pages"])
                pub = f"<br><small>{s['publisher']}</small>" if s.get("publisher") else ""
                st.markdown(f"<div class='agri-source'>📄 <b>{s['title']}</b> — PDF "
                            f"{t(L, 'page')} {pages}{pub}<br><small><code>{s['source']}</code>"
                            f"</small></div>", unsafe_allow_html=True)
            if len(msg.get("queries", [])) > 1:
                st.caption("Searched as: " + " | ".join(msg["queries"]))
            for h in msg.get("hits", [])[:6]:
                m = h["metadata"]
                st.caption(f"[{m['title']} p.{m['page']} · match {h['similarity']:.2f}] "
                           f"{h['text'][:220]}…")

    if status in ("ok", "not_found", "retrieval_only"):
        if msg.get("audio"):
            play_audio(msg["audio"], autoplay=msg.pop("autoplay", False))
        elif wide_button(t(msg.get("lang", L), "listen"), key=f"listen_{i}"):
            try:
                with st.spinner("🔊 …"):
                    msg["audio"], _ = synthesize(msg["content"], msg.get("lang", L),
                                                 config.TTS_BACKEND)
                msg["autoplay"] = True
                st.rerun()
            except TTSError as exc:
                st.error(str(exc))


for i, msg in enumerate(st.session_state.messages):
    with st.chat_message(msg["role"], avatar="🧑‍🌾" if msg["role"] == "user" else "🌱"):
        if msg["role"] == "user":
            st.markdown(msg["content"])
        else:
            render_assistant(i, msg)

# ---------------------------------------------------------------------------
# Input: voice + text
# ---------------------------------------------------------------------------
st.markdown(f"### 💬 {t(L, 'placeholder').rstrip('…')}")

audio_widget = getattr(st, "audio_input", None) or getattr(st, "experimental_audio_input", None)
if audio_widget is None:
    st.info("Voice input needs Streamlit 1.40 or newer: pip install -U streamlit")
else:
    st.caption(t(L, "voice_hint"))
    recording = audio_widget(t(L, "mic"), key=f"mic_{st.session_state.mic_round}")
    if recording is not None:
        audio_bytes = recording.getvalue()
        digest = hashlib.sha1(audio_bytes).hexdigest()
        if digest != st.session_state.last_audio:
            st.session_state.last_audio = digest
            try:
                with st.spinner(t(L, "transcribing")):
                    text = transcribe(audio_bytes, L, st.session_state.stt_backend,
                                      llm=llm_client, whisper_model=config.WHISPER_MODEL)
                st.session_state.voice_error = None
                if st.session_state.auto_send:
                    st.session_state.mic_round += 1
                    ask(text)
                else:
                    st.session_state.question_input = text
                    st.session_state["voice_recognized"] = True
            except STTError as exc:
                st.session_state.voice_error = str(exc)
            except Exception as exc:       # never crash the chat because of voice
                logging.exception("Speech recognition failed")
                st.session_state.voice_error = f"Speech recognition failed: {exc}"
    st.caption("ℹ️ " + t(L, "mic_help"))
    if st.session_state.voice_error:
        st.error("🎤 " + st.session_state.voice_error)

if st.session_state.pop("voice_recognized", False):
    st.success(t(L, "recognized"))

with st.form("ask_form", clear_on_submit=True):
    question = st.text_area(t(L, "placeholder"), key="question_input", height=90,
                            label_visibility="collapsed", placeholder=t(L, "placeholder"))
    c1, c2 = st.columns([3, 1])
    with c1:
        sent = wide_submit("➤ " + t(L, "send"))
    with c2:
        cleared = wide_submit(t(L, "clear"))

if cleared:
    st.session_state.messages = []
    st.session_state.mic_round += 1
    st.rerun()
if sent:
    if question.strip():
        st.session_state.mic_round += 1          # reset the microphone widget
        ask(question.strip())
    else:
        st.warning(t(L, "empty_question"))

# ---------------------------------------------------------------------------
# Answer pending question
# ---------------------------------------------------------------------------
pending = st.session_state.pending
if pending:
    st.session_state.pending = None
    # Answer in the language selected in the header. Exception: if the selector is
    # still on English but the farmer clearly typed/spoke Telugu, Kannada or Hindi,
    # answer in that language.
    detected = detect_language(pending)
    answer_lang = L if L != "en" else (detected if detected in ("te", "kn", "hi") else "en")
    st.session_state.messages.append({"role": "user", "content": pending})
    with st.spinner(t(L, "thinking")):
        try:
            result = get_pipeline().answer(pending, answer_lang)
            msg = {"role": "assistant", "content": result.answer, "status": result.status,
                   "sources": result.sources, "hits": result.hits,
                   "queries": result.search_queries, "lang": answer_lang}
        except Exception as exc:
            logging.exception("Answering failed")
            msg = {"role": "assistant", "status": "error", "lang": answer_lang,
                   "content": f"Something went wrong while answering: {exc}"}
    if st.session_state.auto_speak and msg["status"] in ("ok", "not_found"):
        try:
            msg["audio"], _ = synthesize(msg["content"], answer_lang, config.TTS_BACKEND)
            msg["autoplay"] = True
        except TTSError as exc:
            st.toast(str(exc))
    st.session_state.messages.append(msg)
    st.rerun()

st.markdown(f"<div class='agri-disclaimer'>⚠️ {t(L, 'disclaimer')}</div>",
            unsafe_allow_html=True)
